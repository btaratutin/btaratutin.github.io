""" Code example from Complexity and Computation, a book about
exploring complexity science with Python.  Available free from

http://greenteapress.com/complexity

Copyright 2011 Allen B. Downey.
Distributed under the GNU General Public License at gnu.org/licenses/gpl.html.
"""

import string
import random

from collections import deque

from Graph import *

class RandomGraph(Graph):
    """An Erdos-Renyi random graph is a Graph where the probability 
    of an edge between any two nodes is (p).
    """
    
    def __init__(self, size, p=0.1):
        """ size is the number of vertices to add,
            p is the probability of edge between any given node """
        
        # Creates all the vertices
        for i in xrange(size):
            self.add_vertex(Vertex(i))
            
        self.add_random_edges(p)
        

    def add_random_edges(self, p):
        """Starting with an edgeless graph, add edges to
        form a random graph where (p) is the probability 
        that there is an edge between any pair of vertices.
        """
        vs = self.vertices()
        for i, v in enumerate(vs):
            for j, w in enumerate(vs):
                if j <= i: continue
                if random.random() > p: continue
                self.add_edge(Edge(v, w))


    def bfs(self, s, visit=None):
        """Breadth first search, starting with (s).
        If (visit) is provided, it is invoked on each vertex.
        Returns the set of visited vertices.
        """
        visited = set()

        # initialize the queue with the start vertex
        queue = deque([s])
        
        # loop until the queue is empty
        while queue:

            # get the next vertex
            v = queue.popleft()

            # skip it if it's already visited
            if v in visited: continue

            # mark it visited, then invoke the visit function
            visited.add(v)
            if visit: visit(v)

            # add its out vertices to the queue
            queue.extend(self.out_vertices(v))

        # return the visited vertices
        return visited

    def is_connected(self):
        """Returns True if there is a path from any vertex to
        any other vertex in this graph; False otherwise.
        """
        vs = self.vertices()
        visited = self.bfs(vs[0])
        return len(visited) == len(vs)



def main(script, n=26, p=0.5, *args):
    g = RandomGraph(n, p)
    print g
    
    from GraphWorld import *
    gw = GraphWorld()
    layout = CircleLayout(g)
    gw.show_graph(g, layout)
    gw.mainloop()


if __name__ == '__main__':
    import sys
    main(*sys.argv)
