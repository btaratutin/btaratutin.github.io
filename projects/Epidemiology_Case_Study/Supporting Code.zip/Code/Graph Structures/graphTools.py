# -*- coding: utf-8 -*-
"""
A Suite of Graph Tools/Manipulations, used to aid us in simulation voodoo
"""

from Graph import Graph

def copyGraph(g):
    return Graph(g.vertices(), g.edges())

def generateTestGraph(g, v):
    """Take in a graph and vertex, and returns a new graph with vertex v removed
    (and all attached edges)
    """
    new_graph = Graph(g.vertices(), g.edges())
    new_graph.remove_vertex(v)
    new_graph.name = v
    
    return new_graph
    
def generateTestSuite(graph):
    """Takes in a graph and creates a dictionary of modified graphs that maps
    from each vertex label to the graph with that vertex removed.
    """
    d = {}
    
    for v in graph.vertices():
        d[v] = generateTestGraph(graph, v)
    
    return d
    

def generateTestSuiteGraphs(g):
    """Only returns graphs - no fancy dictinaory mapping (for simulation)
    """
    graphs = []
    
    for v in g.vertices():
        graphs.append(generateTestGraph(g, v))
    
    return graphs