# -*- coding: utf-8 -*-
"""
Graph Metrics

Tools for calculating metrics about a graph like the clustering coefficient,
shortest path, etc.

November 2011
Boris Taratutin, Abe Kim, Margaret-Ann Seger
"""

###------------------------ General Graph Stuff -------------------------------

def count_avg_degree(g):
    """ Calculates the average degree for the graph. (degree=avg. # edges/vertex)
        Note: the total(symmetrical) num. edges/num. vertices is an equivalent calculation
              to finding each individual vertice's num. edges and averaging those.
              (if we didn't have the 'unique' function in g.edges, we'd have to do that)
        Runs O(n^2) - because has to call g.edges """
    return float(len(g.edges(unique=False))) / len(g.vertices())
    #Q: anything I can improve here?


# Written (have question)
def is_connected(g):
    """ Returns 'true' if graph is connected (ie. can get to any node) from
        any start node. Otherwise, returns 'false'
        Runs O(n^2), and quite quite slow. """
    from Fifo import Fifo
    
    
    start_vertex = g.keys()[0] # start at first vertex O(n)
    f = Fifo([start_vertex]) # O(c)
    marked = {}   
    
    # Find all of the connected vertices and add them to 'marked'
    while f: # O(n)?
        vertex = f.pop()
        
        # or marked[vertex] = marked.get(vertex, '')?
        if vertex not in marked: #O(c)?
            marked[vertex] = ''
        
        neighbors = g.out_vertices(vertex) #O(k), k= number of neighbors
        for n in neighbors: #O(k)
            if n not in marked: #O(c)
                f.add(n) #O(c)
                
    # Check whether graph is connected ("yes" if the vertices we found are equal to )
    if len(g.vertices()) == len(marked): #O(n)
        return True
    else:
        return False      
        
    #Q: are my analysis of the Order of Growths in this function correct?
    #Q: this runs O(n^2), can it be improved?


###-------------------- Clustering Alg. (Finding Nearest Neighbors) -------------------

def countNumEdges(g, vertices):
    """ Counts the number of edges that exist between the given vertices (list) """
    num_edges = 0
    
    for i,v in enumerate(vertices):     # Iterate through all nodes
        for n in vertices[i+1:]:        # Iterate through all of node's neighbors n
            if g.get_edge(v, n):
                num_edges += 1
    
    return num_edges


def seq_generator(g, low=0):
    """ Calling next() will generate the sequence [-1, 1, -2, 2, ...]
        Used for accessing a node's nearest --> farthest neighbors.
        
        input: low = the low bound where to start (in terms of i-values)
    """
    i = low     
    while True:
        yield (i/2 + 1) * (-1)**(i+1)
        i += 1
        
        
def clustering_coefficient(g):
    """ Calculates the 'clustering coefficient', a measure of the extent 
        to which a subset of nodes are connected to each other.
        
        Formally, C(x) = probability p that if A & B are connected to C,
                    --> that A is connected to B and B is connected to A 
                    
        First, we calculate C_v for each vertex; 
            C_v = (# edges that exist between neighbors of v) / (total. poss. such edges)
            total_poss_such_edges is given by the formula = k_v * (k_v-1)/2 (k_v = # neighbors of v)
            
        Then, we average all of the C_v-s over the whole graph and return that as 
        our measure of "C", the clustering coefficient, over the whole graph
                    
        """
    
    # Returns number of possible neighbor edge connections for a node with k neighbors
    numPossNeighborEdges = lambda k: k*(k-1)/2.0
    clustering_values = []
    
    for v in g.vertices():
        neighbors = g.out_vertices(v)
        num_n_edges = countNumEdges(g, neighbors)
        num_poss_n_edges = numPossNeighborEdges(len(neighbors))
        
        try:
            clustering_values.append( num_n_edges/num_poss_n_edges )
        except ZeroDivisionError:
            # Node with only 1 neighbor. (Node with 0 neighbors?)
            clustering_values.append(1)
        
    # Return the average 
    return sum(clustering_values)/float(len(clustering_values))


###----------------------------- Print Out some Stats about the Graph ----------

def stats(g):
    """ Prints out some general stats about the graph """
    stats = {}

    stats["Num. Nodes"] = len(g.vertices())
    stats["Num. Edges"] = len(g.edges())
    stats["Avg. Degree"] = count_avg_degree(g)
    stats["Is Connected"] = is_connected(g)
    stats["Clustering Coefficient"] = clustering_coefficient(g)
    #stats["Av.g Shortest Path Length"] = avgShortestPathLength(g)
    
    from dictManip import sortDictGetItems
    
    for (key, val) in sortDictGetItems(stats):
        print key, ": ", val
    
    return stats


if __name__ == "__main__":
    from CompleteGraph import *
    g = CompleteGraph(10)
    print stats(g)
