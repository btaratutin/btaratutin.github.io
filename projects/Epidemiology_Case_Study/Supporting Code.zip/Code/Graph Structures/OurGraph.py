# -*- coding: utf-8 -*-
"""
Created on Fri Dec 09 22:24:20 2011

@author: btaratutin
"""

'''
RegularGraph.py

Took out a section from Graph.py in CompMod Case Study and created
RegularGraph.py
'''

from Graph import *
from GraphWorld import *

class OurGraph(Graph):
    
    def __init__(self, size, k=2):
        """ size is the number of vertices to add,
            k is the degree to create """
            

        # Creates all the vertices
        for i in xrange(size):
            self.add_vertex(Vertex(i))
            
        three_main = self.vertices()[:7]
        others = self.vertices()[7:]
        
        first_half = others[:len(others)/2]
        second_half = others[(len(others)/2):]
        
        for v in first_half:
            self.add_edge(Edge(v, three_main[0]))
            self.add_edge(Edge(v, three_main[1]))
            self.add_edge(Edge(v, three_main[2]))
            
        self.add_edge(Edge(three_main[6], three_main[0]))
        self.add_edge(Edge(three_main[6], three_main[1]))
        self.add_edge(Edge(three_main[6], three_main[2]))
            
            
        for v in second_half:
            self.add_edge(Edge(v, three_main[3]))
            self.add_edge(Edge(v, three_main[4]))
            self.add_edge(Edge(v, three_main[5]))
            
        
        self.add_edge(Edge(three_main[6], three_main[3]))
        self.add_edge(Edge(three_main[6], three_main[4]))
        self.add_edge(Edge(three_main[6], three_main[5]))
            

        
if __name__ == "__main__":
    g = OurGraph(20)
    print g
    
    gw = GraphWorld()
    layout = CircleLayout(g)
    gw.show_graph(g, layout)
    gw.mainloop()