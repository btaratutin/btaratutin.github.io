"""

Created on Mon Nov 14 2011

@author: mseger
"""

from Graph import *
from RandomGraph import *
from GraphWorld import *
import random


class SmallWorldGraph(RegularGraph):
    """Generates a Small-World graph, as defined by Watts-Strogatz"""

    def __init__(self, n, k, p):
        """Creates a Small-World graph with n number of vertices with
            each vertex attached to its k nearest neighbors

            p: determines the proportion of edges that are rewired"""

        # Create the set of vertices
        self.n = n
        self.k = k
        self.p = p
        
        for i in range(n):
            self.add_vertex(Vertex(i))

        # Make the graph a regular graph of degree k
        self.add_regular_edges(k)

        # rewire the graph
        if not self.is_complete():
            self.rewire(k, p)

    def rewire(self, k, p):
            
        for v in self.vertices():
            for i in range(len(self.out_edges(v))):
                if len(self.out_edges(v)) == self.n-1: continue
                #~ print i
                e = self.out_edges(v)[i]
                if p > random.random():
                    # if greater than a certain probability, re-wire
                    possibles = self.vertices()
                    possibles.remove(v)
                    v_new = possibles[random.randint(0, len(possibles)-1)]

                    while self.has_edge(v, v_new):
                        v_new = possibles[random.randint(0, len(possibles)-1)]

                    #self.out_edges(v)[i] = Edge(v, v_new)
                    self.remove_edge(e)
                    self.add_edge(Edge(v, v_new))
    
    def is_complete(self):
        """Checks if the graph is a complete graph INERNAL METHOD"""
        if self.k == self.n-1: return True
        return False
    
    

if __name__ == "__main__":
    """Test function to display small world graph after a few-rewirings"""

    swg = SmallWorldGraph(10, 9, 0.4)

    # display using SmallWorldGraph
    gw = GraphWorld()
    layout = CircleLayout(swg)
    gw.show_graph(swg, layout)
    gw.mainloop()
