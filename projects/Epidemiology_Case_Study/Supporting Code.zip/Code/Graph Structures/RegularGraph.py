'''
RegularGraph.py

Took out a section from Graph.py in CompMod Case Study and created
RegularGraph.py
'''

from Graph import *

class RegularGraph(Graph):
    
    def __init__(self, size, k=2):
        """ size is the number of vertices to add,
            k is the degree to create """
        
        # Creates all the vertices
        for i in xrange(size):
            self.add_vertex(Vertex(i))
            
        # Adds all the edges
        self.add_regular_edges(k)
    
                
    def add_regular_edges(self, k=2):
        """Make a regular graph with degree k if possible;
        otherwise raises an exception."""
        vs = self.vertices()
        if k >= len(vs):
            raise ValueError, ("cannot build a regular graph with " +
                               "degree >= number of vertices.")

        if is_odd(k):
            if is_odd(len(vs)):
                raise ValueError, ("cannot build a regular graph with " +
                                   "an odd degree and an odd number of " +
                                   "vertices.")
            self.add_regular_edges_even(k-1)
            self.add_regular_edges_odd()
        else:
            self.add_regular_edges_even(k)

    def add_regular_edges_even(self, k=2):
        """Make a regular graph with degree k.  k must be even"""
        vs = self.vertices()
        double = vs * 2
        
        for i, v in enumerate(vs):
            for j in range(1,k/2+1):
                w = double[i+j]
                self.add_edge(Edge(v, w))

    def add_regular_edges_odd(self):
        """Adds an extra edge "across" the graph to finish off a regular
        graph with odd degree.  The number of vertices must be even."""
        vs = self.vertices()
        n = len(vs)
        reduplicated_list = vs * 2
        
        for i in range(n/2):
            v = reduplicated_list[i]
            w = reduplicated_list[i+n/2]
            self.add_edge(Edge(v, w))
"""
    def bfs(self, s, visit=None):
        Breadth first search.

        s: start vertex
        visit: function called on each vertex
        

        # mark all the vertices unvisited
        for v in self.vertices():
            v.visited = False

        # initialize the queue with the start vertex
        queue = [s]
        
        while queue:

            # get the next vertex
            v = queue.pop(0)

            # skip it if it's already marked
            if v.visited: continue

            # mark it visited, then invoke visit
            v.visited = True
            if visit: visit(v)

            # add its out vertices to the queue
            queue.extend(self.out_vertices(v))
"""

def is_odd(x):
    return x % 2
        
        
if __name__ == "__main__":
    g = RegularGraph(10)
    print g