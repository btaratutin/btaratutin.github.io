# -*- coding: utf-8 -*-
"""
Created on Fri Nov 11 14:18:53 2011

@author: btaratutin
"""

from Graph import *

class CompleteGraph(Graph):
    """ Generates a complete graph """
    
    def __init__(self, size):
        """ Creates a complete graph of size [size] """
        
        # Create the Vertices
        for i in xrange(size):
            self.add_vertex(Vertex(i))
            
        # Connect all the vertices
        self.connect_all_edges()

    # Written (have a question)
    def connect_all_edges(self):
        """ Makes the graph complete (adds all the edges). O(n^2)."""
        vertices = self.vertices()
        
        for i, v in enumerate(vertices):
            for neighbor in vertices[i+1:]:
                e = Edge(v, neighbor)                
                self.add_edge(e)
                

if __name__ == "__main__":
    g = CompleteGraph(5)
    print g