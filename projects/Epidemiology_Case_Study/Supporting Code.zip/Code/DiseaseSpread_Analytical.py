"""
Disease Model Analytical Method

@Author: Margaret-Ann, Abe

Date: 11/16/2011
"""
import sys
sys.path.append("Graph Structures")
sys.path.append("Tools")

from CompleteGraph import *
import copy
import dictManip
import dijkstra as dj
from EasyPlot import EasyPlot, convertListPoints
from Graph import Graph, Vertex, Edge
import GraphMetrics
import GraphWorld as gw
import math
from RandomGraph import *
from RegularGraph import *
from ScaleFreeGraph import *
from SmallWorldGraph import *
import graphTools


def heuristicTest(graphs, threshold):
    """Takes in a dictionary of graphs and runs the heuristic test. 
    Returns the average of all the heuristic values and a dictionary that
    maps from the difference in heuristic for a tested graph to the 
    removed vertex.
    """
    #threshold = the average shortest path for the original graph
    average = 0.0 # avg. used to calculate the result for the whole graph
    hdict = {}
    
    for v in graphs.keys():
        value = round(math.fabs(dj.avg_shortest_path(graphs[v])-threshold)/threshold, 3)
        hdict[value] = hdict.get(value, [])
        hdict[value].append(v)
        average += value
        #print heuristic
    
    # Returns 
    return (average/len(graphs.keys()), hdict)
    
def getTopPairs(d):
    """ Gets the top pairs from the dict d, using the key to sort """
    
    li = d.keys()
    li.sort(reverse=True)
    
    output = []
    # Print the five largest discrepencies and the vertices, whose removal
    # returned these results.
    for key in li:
        output.append( (key, d[key]) )
        
    return output
    
    
def main(g, N=10):
    """ Runs the heuristic on graph g, and returns the top N nodes """
    # Create the threshold based on the generated graph
    threshold = dj.avg_shortest_path(g)
    
    # Run test
    suite = graphTools.generateTestSuite(g)
    h, hdict = heuristicTest(suite, threshold)
    
    # Sort them
    sorted_vals = getTopPairs(hdict)[:N]
    
    return sorted_vals
    
    

if __name__=='__main__':
    # Easy-to-implement graph
    graphs = {'complete': CompleteGraph, 'random': RandomGraph,
          'regular': RegularGraph, 'scalefree': ScaleFreeGraph,
          'smallworld': SmallWorldGraph}
    
    # Generate a graph
    g = graphs['regular'](20, k=2)
    
    # Create the threshold based on the generated graph
    threshold = dj.avg_shortest_path(g)
    #dj.heuristicv2(g)
    
    # Run test
    suite = graphTools.generateTestSuite(g)
    h, hdict = heuristicTest(suite, threshold)
    
    # Print the average heuristic resulting from the test, the actual
    # threshold and the difference in the two.
    print h, threshold, math.fabs(h-threshold)
    
    # Sort the difference between the threshold and heuristic
    li = hdict.keys()
    li.sort(reverse=True)
    
    
    # Print the five largest discrepencies and the vertices, whose removal
    # returned these results.
    for i, p in enumerate(li):
        vertices = hdict[p]
        print (p,vertices)
        if i == 0:
            for v in vertices:
                v.color = 'red'
        elif i == 1:
            for v in vertices:
                v.color = 'yellow'
        elif i == 2:
            for v in vertices:
                v.color = 'blue'

    # Plot it
    #gw.plotGraph(g, 'circle')
    #raw_input()
