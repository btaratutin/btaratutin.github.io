# -*- coding: utf-8 -*-
"""
May 30, 2011
Boris Taratutin

The 'SaveFiles' module provides basic tools for saving data to files -
generally csvs or via pickling. Data is usu. lists, arrays, dicts, etc.
"""

import os
import re

# My Modules
import dictManip



def overwriteprotection(f):
    """ Checks to see whether the given file (path inclued) already exists.
        If it does, then adds " (n)" to the end of the file, so it doesn't get
        overwritten.
        
        Returns new filename if it would've been overwritten
        Returns same filename if no danger of overwriting file
    """
        
    if os.path.exists(f):
        while os.path.exists(f):
            
            # try to see if file already has " (n)" designation
            num = re.search(r".*\((?P<num>\d+)\)", f)
            if num:
                # if it does, increment the number, and insert that into
                # the filename. Next iteration, we'll try again with that name
                new_num = int(num.group('num')) + 1
                (start_i, end_i) = num.span('num')
                f = f[:start_i] + str(new_num) + f[end_i:]
                
            else:
                # If no " (n)" designation, add it
                ext_i = f.rfind(".")
                f = f[:ext_i] + " (1)" + f[ext_i:]
            
    
    # If file doesn't exist at all, don't modify it. Return same file name
    # If file existed, it has been modified by now
    return f

def saveDictToCSV(d, name, path):
    """ Saves the given dict to the path as a csv """
    filename = path + "\\" + name + ".csv"
    filename = overwriteprotection(filename)
    f = file(filename, 'w')
    
    # Sort the dictionary and get a list of (key, val) pairs
    printable_dict = dictManip.sortDictGetItems(d)
    
    for key, val in printable_dict:
        f.write( "%s,%s\n" % (key, val) )
        
    f.close()
