# Margaret-Ann Seger, Implementation of Dijkstra's Algorithm


import sys
sys.path.append("Graph Structures")
sys.path.append("Tools")

import Cdf
from CompleteGraph import *
import dictManip
import GraphMetrics
from GraphWorld import *
import myplot
import Pmf
from RegularGraph import *
import sys

def dijkstra(graph, node1):
    """Computes the shortest path from an input node to every other node
    in the graph"""

    # initialize everything and fill in the first entry
    path = dict()
    li = []
    node_len = dict()
    queue = []
    seen = []
    len_out = 0
    
    #incr_amount = 1.0 / len(graph.edges())
    
    for vertex in graph.vertices():
        path[vertex] = []
        node_len[vertex] = len(graph.vertices())+1 #set default @ infinity, and then overwrite later if find

	node_len[vertex] = 0
    queue.append(node1)
    seen.append(node1)
    len_out += 1

    while len(queue) != 0:
        currNode = queue.pop(0)
        next_level = graph.out_vertices(currNode)
        for node in next_level:
            if not(node in seen):
                path[node]= path.get(currNode,[]) + [node]
                node_len[node] = node_len[currNode] + 1
                queue.append(node)
                seen.append(node)

    for key in path.keys():
        for item in path.get(key):
            li.append(item)
    
    freq = Pmf.MakeHistFromList(li)
    return node_len, freq

def avg_shortest_path_vertex(graph, v):
    """Computes the average shortest path length between vertex v and all
    other nodes in the graph
    """
    avg = 0
    node_len = dijkstra(graph, v)[0]
    
    for entry in node_len.keys():
        avg += 1.0* node_len[entry]/(len(node_len.keys())-1)
    
    return avg

def avg_shortest_path(graph):
    """Computes the average of all the shortest paths between all pairs of
    nodes in a connected graph"""

    verts = graph.vertices()
    #~ start = verts[0]
    averages = []
    
    for v in verts:
        avg = 0
        node_len = dijkstra(graph, v)[0]
        for entry in node_len.keys():
            avg += 1.0 * node_len[entry]/(len(node_len.keys())-1)
        averages.append(avg)
    
    return sum(averages)/len(averages)

def mostFrequent(graph):
    """Returns the most frequently visited node from the given graph.
    """
    verts = graph.vertices()
    allFreq = Pmf.Hist()
    
    for v in verts:
        allFreq.Add(dijkstra(graph,v)[1])
    
    return dictManip.getTopN(allFreq.d)

def mostFrequent2(graph):
    verts = graph.vertices()
    allFreq = Pmf.Hist()
    
    for v in verts:
        allFreq.Add(dijkstra(graph,v)[1])
    
    return allFreq.d

def heuristicv3(graph):
    """Returns P(X <= threshold), where X is the shortest path length of
    a random node chosen from the given graph and the threshold is the
    average shortest path length of all nodes.
    """
    verts = graph.vertices()
    g_avg_shortest_path = avg_shortest_path(graph)
    
    count = 0
    
    for v in verts:
        individual_v_avg_shortest_path = avg_shortest_path_vertex(graph, v)
        if individual_v_avg_shortest_path - g_avg_shortest_path >= -10**-12: count += 1
        print "shortest path for ", v, " : ", individual_v_avg_shortest_path
    
    print "graph: ", g_avg_shortest_path
    print "count: ", count
    print "len verts: ", len(verts)
    return 1.0 * count/len(verts)

if __name__ == '__main__':
    # create a complete, regular graph for testing purposes
    
    #~ g.add_regular_edges()
    #g.add_all_edges()
    """
    li = []
    for i in range(1000):
        g =  RandomGraph(100)
        li.append(heuristicv3(g))
    pmf = Pmf.MakePmfFromList(li)
    cdf = Cdf.MakeCdfFromList(li)
    """
    g = RandomGraph(10)
    print mostFrequent(g)
    
    myplot.Cdf(pmf, show=True, legend=False)
    
    #~ length, freq = dijkstra(g, g.vertices()[0])
    #~ print length
    #~ print
    #~ print freq.Items()
    #~ print avg_shortest_path(g)
    #~ print
    #~ print mostFrequent(g)
    
    
    #~ layout = CircleLayout(g)
    #~ gw = GraphWorld()
    #~ gw.show_graph(g, layout)
    #~ gw.mainloop()
    
