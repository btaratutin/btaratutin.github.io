'''
Analytical Method

@author: akim
'''

import djikstra
import connectivity

def analytics():
