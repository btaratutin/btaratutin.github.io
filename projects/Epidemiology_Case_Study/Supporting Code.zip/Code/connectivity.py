"""
Connectivity

@authors: mseger, akim
"""
import sys

sys.path.append("Graph Structures")
sys.path.append("Tools")

from Graph import *
from operator import itemgetter

def connectivity(graph, v):
    '''Returns the degree of v'''
    return len(graph.out_vertices(v))

def graph_connectivity(graph):
    '''Returns a list of nodes sorted in decreasing order of connectivity'''
    li = [(v, connectivity(graph, v)) for v in graph.vertices()]
    return sorted(li, key=itemgetter(1), reverse=True)

if __name__ == '__main__':
    v1 = Vertex('v1')
    v2 = Vertex('v2')
    v3 = Vertex('v3')
    v4 = Vertex('v4')
    v5 = Vertex('v5')

    e1 = Edge(v1, v2)
    e2 = Edge(v1, v3)
    e3 = Edge(v1, v4)
    e4 = Edge(v1, v5)

    g = Graph([v1, v2, v3, v4, v5], [e1, e2, e3, e4])

    print connectivity(g, v1)
    print connectivity(g, v2)

    print graph_connectivity(g)
