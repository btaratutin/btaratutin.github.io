# -*- coding: utf-8 -*-
"""
Common methods to all the disease spread modules
"""

import sys
sys.path.append("Graph Structures")
sys.path.append("Tools")

from Graph import *

from RegularGraph import RegularGraph
from RandomGraph import RandomGraph
from ScaleFreeGraph import ScaleFreeGraph
from CompleteGraph import CompleteGraph
from SmallWorldGraph import SmallWorldGraph



class DiseaseSpreadModel(Graph):
    """ Holds a modified graph object (self.g) with the added attributes:
            (that allow us to simulate the spread of disease using this graph)
            g.vertex.state
            g.vertex.days_latent
            g.vertex.days_infectious
            
        Also has methods useful in simulatio
    """
    
    def __init__(self, graph_type, n, **kwargs):
        """ Initializes self to have a graph reference to specified graph type 
            (with n nodes and kwargs (anything else that need to define graph))
            
            Possible graph types are: complete, random, regular, small world, scale free"""
            
        # Dictionary that maps named graphs to their init functions
        graphs = {'complete': CompleteGraph, 'random': RandomGraph,
          'regular': RegularGraph, 'scalefree': ScaleFreeGraph,
          'smallworld': SmallWorldGraph}
          
        # Create the graph that will be using
        self.g = graphs[graph_type](n, **kwargs)
        
        # Convert the 'standard' graph definition to have characteristics of a
        # Disease-Model
        convertModeltoDiseaseModel(self.g)
        
        
def diseaseModelGraphCopy(g):
    """ Turns a graph into a disease model, and copies it """
    new_g = Graph(g.vertices(), g.edges())
    convertModeltoDiseaseModel(new_g)
    return new_g

def convertModeltoDiseaseModel(g):
    """ converts all the vertices in graph g to fit the Disease spread model.
    
    Gives the vertices the following attributes:
        - state: 
            -- 0 normal:    vertex (person) has not been infected yet.
            -- 1 infected:  vertex (person) has contracted disease and is going through latency period
                            before becoming infectious. Cannot infect other nodes. Cannot be re-infected.
                            lasts for [latent_period]
            -- 2 infectious:vertex (person) has the disease and can infect others.
                            lasts for [infectious_period]
            -- 3 immune:    vertex (person) has finished infectious period and 'recovered'
                            Can no longer be infected, can no longer infect others
        - days_latent: # of days that infected individual has been infected for (use to count to get to 'infectious' state)
        - days_infectious: # of days individual has been infectious. (use to count to get to 'immune' state)
    """
    
    for v in g.vertices():
        v.state = "normal"
        v.days_latent = 0
        v.days_infectious = 0
        



if __name__ == "__main__":
    disease_graph = DiseaseSpreadModel("scalefree", n=10)   # Create Disease Model Graph
    disease_graph.g.vertices()[0].state = "infected"        # Simulate infecting a node
    print disease_graph.calcStats()                         # Get the stats
        
    
    
    