# -*- coding: utf-8 -*-
"""
Created on Tue Dec 06 14:59:50 2011

@author: btaratutin
"""

# Add subfolders
import sys
sys.path = ["Graph Structures", "Tools"] + sys.path

from OurGraph import *
import random

from DiseaseSpread_Simulation import *
from DiseaseSpread_Analytical import *

import graphTools
import dictManip
import dijkstra

from EasyPlot import EasyPlot, convertListPoints
from DiseaseSpreadModel import DiseaseSpreadModel, diseaseModelGraphCopy


def runTest(base_graph, nodes_to_remove, p_infection, latent_period, infectious_period, num_avgs, plt, graph_name):
    print "\n\nStarting simulation."
    base_population_size = len(base_graph.vertices())
    epidemic_sizes = []
    num_nodes_removed = []
    
    base_graph = diseaseModelGraphCopy(base_graph)
    print "starting with stats:"
    print calcStats(base_graph)
    
    base_epidemic_size = Averaged_Simulation(base_graph, p_infection, latent_period, infectious_period, num_avgs)
    print "Base epidemic size: ", base_epidemic_size
    epidemic_sizes.append(base_epidemic_size)
    num_nodes_removed.append(0)
    
    for i, node in enumerate(nodes_to_remove):
        base_graph = graphTools.generateTestGraph(base_graph, node)
        if len(base_graph.vertices()) == 0:
            print "breaking out. no more nodes to remove"
            break
        epidemic_size = Averaged_Simulation(base_graph, p_infection, latent_period, infectious_period, num_avgs)       
        epidemic_sizes.append(epidemic_size)
        print "removing node ", node, " yields ", epidemic_sizes[-2]-epidemic_size, " smaller epidemic size"
        num_nodes_removed.append(i+1)
    
    node_proportions = [n/float(len(num_nodes_removed)) for n in num_nodes_removed]
    epidemic_proportions = [e/float(base_population_size) for e in epidemic_sizes]
    

    # Plot the results
    plt.addPlot(node_proportions, epidemic_proportions, label=graph_name)
    

if __name__ == "__main__":
    """ Start with a graph where a disease has an almost certain chance of becoming pandemic 
    
        Find the top N nodes, analytically for a graph.
        Then, go through them and start removing nodes, until the epidemic size
        drops significantly - and essentially, we've found the 'tipping point' of
        the number of nodes that need to be removed in order to stop a pandemic
    """
    
    # Constants
    graphs = {'complete': CompleteGraph, 'random': RandomGraph,
          'regular': RegularGraph, 'scalefree': ScaleFreeGraph,
          'smallworld': SmallWorldGraph, 'ourgraph': OurGraph}
    
    # Graph Parameters
    graph_type = "random"    # Graph topology to generate
    n = 150                   # Number of nodes within graph #120
    kwargs = {}
    base_graph = graphs[graph_type](n, **kwargs)
    
    # Simulation Parameters
    """ These must be very particular, in order to near-guarantee a pandemic infection
        p_infection * infectious period ~= 1.2 """
    p_infection = 0.1
    latent_period = 3
    infectious_period = 3
    num_avgs = 25 # the higher, the better!
    

    
    plt = EasyPlot("Epidemic Size vs. # nodes removed. n:%s, p:%s, latent:%s, infectious:%s, num_avgs:%s" % (n, p_infection, latent_period, infectious_period, num_avgs), 
                   "Proportion of Nodes Removed", "Proportion of Nodes Infected", titlesize=13, scale=None)  
    
    # Random Method
    nodes_to_remove = []
    nodes_to_remove = base_graph.vertices()
    random.shuffle(nodes_to_remove)
    runTest(base_graph, nodes_to_remove, p_infection, latent_period, infectious_period, num_avgs, plt, "Random")
     
     
    # Analytic Method
    """
    nodes_to_remove = []
    analytical_results = DiseaseSpread_Analytical.main(base_graph, -1)
    for val, n in analytical_results:
        nodes_to_remove.extend(n)
    
    print "analytical"    
    print nodes_to_remove
    runTest(base_graph, nodes_to_remove, p_infection, latent_period, infectious_period, num_avgs, plt, "Heuristic")
    """
       
    
    # Most Frequent Method
    """
    nodes_to_remove = []
    nodes_to_remove = dijkstra.mostFrequent2(base_graph)
    print "most frequent nodes to remove"    
    print nodes_to_remove
    nodes_to_remove = dictManip.sortDictGetItems(nodes_to_remove, key=1, reverse=True)
    nodes_to_remove = [node for node, degree in nodes_to_remove]
    print nodes_to_remove
    runTest(base_graph, nodes_to_remove, p_infection, latent_period, infectious_period, num_avgs, plt, "Highest pass-through")
    """

    # Highest Degree Method
    nodes_to_remove = {}
    
    for node in base_graph.vertices():
        nodes_to_remove[node] = len(base_graph.out_vertices(node))
        
    nodes_to_remove = dictManip.sortDictGetItems(nodes_to_remove, key=1, reverse=True)
    print "\nHighest Degree Method:"
    print nodes_to_remove
    nodes_to_remove = [node for node, val in nodes_to_remove]
    runTest(base_graph, nodes_to_remove, p_infection, latent_period, infectious_period, num_avgs, plt, "Highest Degree")
    
         

     
    # Simulation Method
    nodes_to_remove = []
    simulation_results = Node_Removal_Averaged_Simulation(base_graph, p_infection, latent_period, infectious_period, num_avgs)
    print "\nSimulation Method:"
    print simulation_results    
    nodes_to_remove =  [node for node,val in simulation_results]
    runTest(base_graph, nodes_to_remove, p_infection, latent_period, infectious_period, num_avgs, plt, "Simulation")

    import GraphWorld as gw
    gw.plotGraph(base_graph, layout="force")
    
    plt.plot()
