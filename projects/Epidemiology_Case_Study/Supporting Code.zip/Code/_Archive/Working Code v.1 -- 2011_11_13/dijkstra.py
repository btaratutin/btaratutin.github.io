# Margaret-Ann Seger, Implementation of Dijkstra's Algorithm

import sys

sys.path.append('/home/abekim/Dropbox/Ubuntu/CompMod/CompMod\ Case\ Study/In\ Development/')

from RegularGraph import *
from GraphWorld import *

def dijkstra(graph, node1):
    """Computes the shortest path from an input node to every other node
    in the graph"""

    # initialize everything and fill in the first entry
    node_len = dict()
    queue = []
    seen = []
    len_out = 0
    
    for vertex in graph.vertices():
        node_len[vertex] = 'infinity'

    node_len[node1] = 0
    queue.append(node1)
    seen.append(node1)
    len_out += 1

    while len(queue) != 0:
        currNode = queue.pop(0)
        next_level = graph.out_vertices(currNode)
        for node in next_level:
            if not(node in seen):
                node_len[node] = node_len[currNode]+1
                queue.append(node)
                seen.append(node)
    return node_len   

def avg_shortest_path(graph):
    """Computes the average of all the shortest paths between all pairs of
    nodes in a connected graph"""

    verts = graph.vertices()
    start = verts[0]
    avg = 0
    
    node_len = dijkstra(graph, start)
    for entry in node_len.keys():
        avg += 1.0* node_len[entry]/len(node_len.keys())

    return avg
        
    
# create a complete, regular graph for testing purposes

g =  RegularGraph(10)
#~ g.add_regular_edges()
#g.add_all_edges()

print dijkstra(g, g.vertices()[0])
print avg_shortest_path(g)

layout = CircleLayout(g)
#gw = GraphWorld()
#gw.show_graph(g, layout)
#gw.mainloop()
