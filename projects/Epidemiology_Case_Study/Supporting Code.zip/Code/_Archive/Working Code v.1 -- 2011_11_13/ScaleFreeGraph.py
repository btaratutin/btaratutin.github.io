# -*- coding: utf-8 -*-
"""
Scale-Free Graph Structure
November 2011

Boris Taratutin, Abe Kim, Margaret-Ann Seger
"""

from Graph import Graph, Vertex, Edge

import random


class ScaleFreeGraph(Graph):
    """ Implements the "scale-free" graph described by Barabassi-Albert, using:
        - Preferential Attachment (new node X is more likely to attach to 
            nodes in the network that already have )
    """
    
    
    
    def __init__(self, size):
        """ Builds a scale-free graph of the given size
        
            The first node must be initiated manually, and then we keep trying the
            probabalistic preferntial-attachment function until the new node
            connects to >= 1 nodes in the network
            
            We stop when the network reaches size [size]"""
        
        # keep track of how many nodes we've created, and what the name of the next node should be
        self.node_count = 0
        
        # Manually add the first node, to 'kick-off' the graph generation process
        self.add_vertex(Vertex(self.node_count))
        self.node_count += 1
        
        # Try, using preferential attachment, until reach the specified network size
        while self.node_count < size:
            self.addNode(Vertex(self.node_count))      
            
    
    def addNode(self, v, require_connection=True):
        """ Adds a node to the graph using the preferential attachment method 
            Note: node may not actually connect to any existing nodes in the network.
            The "require_connection" variable allows you to specify where its ok (False)
            to have a disconnected node or not (True) (if not, node will be deleted upon
            non-successful attachment) """
        self.add_vertex(v) # adds the node (vertex)
        
        # Iterate through all the existing edges and see if we should form a connection
        # Preferntial attachment: degree of Node/total graph degree (aka total # edges - double counting incl.)
        tot_graph_degree = float(len(self.edges(unique=False)))
        
        # Iterate
        for node in self.vertices():
            
            # Don't connect to self
            if node == v:
                continue
            
            # Probability of our vertex v attaching to node n is n's degree/total graph degree
            try:
                node_degree = len(self.out_edges(node))
                p_attachment = node_degree/tot_graph_degree
            except ZeroDivisionError:
                p_attachment = 1.0 # will only happen when graph has <=2 nodes, disconnected
            
            # If probability is in our favor, add an edge to that node!
            if random.random() <= p_attachment:
                self.add_edge(Edge(v, node))
                
        # Ultimately, node could have formed no connections. Test for this
        node_added = len(self.out_edges(v)) > 0
        
        # If node developed no connections, and we require a connection, delete it from the graph
        if not node_added and require_connection:
            self.remove_vertex(v)
        else:
            self.node_count += 1

        return node_added
                
                

if __name__ == "__main__":
    """ Test function for seeing if scale-free graph is being created properly """
    g = ScaleFreeGraph(10)
    
    print g
    g.stats()