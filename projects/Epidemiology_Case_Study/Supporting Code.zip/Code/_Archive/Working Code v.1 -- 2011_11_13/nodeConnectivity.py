# Margaret-Ann Seger, Implementation of Dijkstra's Algorithm

from Graph import *
from GraphWorld import *

def nodeConn(graph, node1):
    """Computes the shortest path from an input node to every other node
    in the graph"""

    # initialize everything and fill in the first entry
    node_len = dict()
    queue = []
    seen = []
    len_out = 0
    
    for vertex in graph.vertices():
        node_len[vertex] = 'infinity'

    node_len[node1] = 0
    queue.append(node1)
    seen.append(node1)
    len_out += 1

    while len(queue) != 0:
        currNode = queue.pop(0)
        next_level = graph.out_vertices(currNode)
        for node in next_level:
            if not(node in seen):
                node_len[node] = node_len[currNode]+1
                queue.append(node)
                seen.append(node)
    return node_len   
    
# create a complete, regular graph for testing purposes

a = Vertex('a')
b = Vertex('b')
c = Vertex('c')
d = Vertex('d')
e = Vertex('e')
f = Vertex('f')
g = Vertex('g')

vs = [a, b, c, d, e, f, g]
g =  Graph(vs)
g.add_regular_edges()
#g.add_all_edges()

print dijkstra(g, a)

layout = CircleLayout(g)
gw = GraphWorld()
gw.show_graph(g, layout)
gw.mainloop()


