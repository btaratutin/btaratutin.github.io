""" Code example from Complexity and Computation, a book about
exploring complexity science with Python.  Available free from

http://greenteapress.com/complexity

Copyright 2011 Allen B. Downey.
Distributed under the GNU General Public License at gnu.org/licenses/gpl.html.
"""

import string
import random
import math

from itertools import chain

from Gui import Gui
from Gui import GuiCanvas

from Graph import Graph, Vertex, Edge
from RegularGraph import RegularGraph
from RandomGraph import RandomGraph
from ScaleFreeGraph import ScaleFreeGraph
from CompleteGraph import CompleteGraph


class GraphCanvas(GuiCanvas):
    """a GraphCanvas is a canvas that knows how to draw Vertices
    and Edges"""

    def draw_vertex(self, v, r=0.55):
        """draw a Vertex as a yellow circle with radius (r)
        and text (v.label)"""
        tag = 'v%d' % id(self)

        try:
            color = v.color
        except:
            color = 'white'

        self.circle(v.pos, r, color, tags=tag)
        self.text(v.pos, v.label, 'black', tags=tag)
        return tag

    def draw_edge(self, e):
        """draw an Edge as a line between the positions of the
        Vertices it connects"""
        v, w = e
        tag = self.line([v.pos, w.pos])
        return tag


class GraphWorld(Gui):
    """GraphWorld is a Gui that has a Graph Canvas and control buttons."""
    
    def __init__(self):
        Gui.__init__(self)
        self.title('GraphWorld')
        self.setup()
        self.layout = None

    def setup(self):
        """Create the widgets."""
        self.ca_width = 800
        self.ca_height = 800
        xscale = self.ca_width / 30
        yscale = self.ca_height / 30
        self.scale = xscale

        # canvas
        self.col()
        self.canvas = self.widget(GraphCanvas, scale=[xscale, yscale],
                              width=self.ca_width, height=self.ca_height,
                              bg='white')
        
        # buttons
        self.row()
        self.bu(text='Clear', command=self.clear)
        self.bu(text='Quit', command=self.quit)
        self.endrow()

    def show_graph(self, g, layout):
        """Draws the Vertices and Edges of Graph (g) using the
        positions in Layout (layout).
        """

        # copy the positions from the layout into the Vertex objects
        for v in g.vertices():
            v.pos = layout.pos(v)
        
        # draw the edges and store the tags in self.etags, which maps
        # from Edges to their tags
        c = self.canvas
        self.etags = {}
        for v in g:
            self.etags[v] = [c.draw_edge(e) for e in g.out_edges(v)]

        # draw the vertices and store their tags in a list
        self.vtags = [c.draw_vertex(v) for v in g]

    def clear(self):
        """Delete all canvas items."""
        tags = chain(self.vtags, *self.etags.itervalues())
        for tag in tags:
            self.canvas.delete(tag)


class Layout(dict):
    """A Layout is a mapping from vertices to positions in 2-D space."""

    def __init__(self, g):
        for v in g.vertices():
            self[v] = (0, 0)

    def pos(self, v):
        """Returns the position of this Vertex as a tuple."""
        return self[v]

    def distance_between(self, v1, v2):
        """Computes the Euclidean distance between two vertices."""
        x1, y1 = self.pos(v1)
        x2, y2 = self.pos(v2)
        dx = x1 - x2
        dy = y1 - y2
        return math.sqrt(dx**2 + dy**2)
        
    def dxdy_between(self, v1, v2):
        x1, y1 = self.pos(v1)
        x2, y2 = self.pos(v2)
        dx = x2 - x1
        dy = y2 - y1
        return (dx, dy)
        

    def sort_by_distance(self, v, others):
        """Returns a list of the vertices in others sorted in
        increasing order by their distance from v."""
        t = [(self.distance_between(v, w), w) for w in others]
        t.sort()
        return [w for (d, w) in t]


class CircleLayout(Layout):
    """Creates a layout for a graph with the vertices equally
    spaced around the perimeter of a circle."""

    def __init__(self, g, radius=9):
        """Creates a layout for Graph (g)"""
        vs = g.vertices()
        theta = math.pi * 2 / len(vs)
        for i, v in enumerate(vs):
            x = radius * math.cos(i * theta)
            y = radius * math.sin(i * theta)
            self[v] = (x, y)


class RandomLayout(Layout):
    """Create a layout with each Vertex at a random position in
    [[-max, -max], [max, max]]."""

    def __init__(self, g, max=10):
        """Creates a layout for Graph (g)"""
        self.max = max
        for v in g.vertices():
            self[v] = self.random_pos()

    def random_pos(self):
        """choose a random position and return it as a tuple"""
        x = random.uniform(-self.max, self.max)
        y = random.uniform(-self.max, self.max)
        return x, y

    def spread_vertex(self, v, others, min_dist=2.0):
        """Keep choosing random positions for v until it is at least
        min_dist units from the vertices in others.

        Each time it fails, it relaxes min_dist by 10%.
        """
        while True:
            t = [(self.distance_between(v, w), w) for w in others]
            d, w = min(t)
            if d > min_dist:
                break
            min_dist *= 0.9
            self[v] = self.random_pos()

    def spread_vertices(self):
        """Moves the vertices around until no two are closer together
        than a minimum distance."""
        vs = self.keys()
        others = vs[:]
        for v in vs:
            others.remove(v)
            self.spread_vertex(v, others)
            others.append(v)


class ForceDirectedLayout(RandomLayout):
    
    def __init__(self, g, scale):
        # First initialize as a random graph
        self.max = scale/2
        self.scale = scale
        for v in g.vertices():
            self[v] = self.random_pos()
            v.velocity_x = 0
            v.velocity_y = 0
            v.position_x = self[v][0]
            v.position_y = self[v][1]
            
            
        # Then, perform force directed layout
        self.forceLayout(g)
            
    
    def coulombRepulsion(self, v1, v2, k_e=1.0, q=1.0):
        """ calculates the repulsive force between two vertices
            F = k_e * (q1 * q2) / r**2 
                k_e is propotioality constant
                r is radius (distance) between charges
                q is the charge of each point """
        dx, dy = self.dxdy_between(v1, v2)
        return (k_e * (q*q) / dx**2, k_e * (q*q) / dy**2)
        
    def hookesAttraction(self, e, k=1, l=1):
        """ calculates the spring attraction force for a given edge 
            F = -kx
                k = spring constant
                x = displacement between equilibrium length and current length
                l = equilibrium length of spring (in the dx and dy direction)"""
        dx, dy = self.dxdy_between(*e)
        return (-1.0 * k * (l-dx), -1.0 * k * (l-dy))
        
        
            
    def forceLayout(self, g, steps=50, damping=0.9):
        #dt = 10.0/steps
        dt = 0.001
        k_e = 0.2
        q = 0.5
        k = 10
        l = 1 
        
        for step in xrange(steps):
            #total_kinetic_energy = 0 # running sum of total kinetic energy over all particles
            vs = g.vertices()
            random.shuffle(vs)
            for v in vs:
                F_x=0; F_y=0
                
                # Calculate magnetic force repulsions for all nodes
                others = g.vertices()
                others.remove(v)
                
                # Define corners/edges of screen as 'vertices':
                """
                for x in xrange(2):
                    for y in xrange(2):
                        v = Vertex("%s%s" % (x, y) )
                        v.pos = (self.scale * (-1)**x, self.scale * (-1)**y)
                        others.append(v)
                """
            
                for o in others:
                    F = self.coulombRepulsion(v, o, k_e, q)
                    F_x += F[0]
                    F_y += F[1]
                
                # Calculate spring compressions for connected edges
                for e in g.out_edges(v):
                    F = self.hookesAttraction(e, k, l)
                    F_x += F[0]
                    F_y += F[1]
                    
                v.velocity_x += dt * F_x * damping
                v.velocity_y += dt * F_y * damping
                
                v.position_x += dt * v.velocity_x
                v.position_y += dt * v.velocity_y

        # Save results
        for v in g.vertices():
            v.pos = (v.position_x, v.position_y)
            self[v] = v.pos

def updateGraph(gw, g):
    #gw.clear()
    #gw.show_graph(g, gw.layout)
    for v in g:
        gw.canvas.draw_vertex(v)
    #c.draw_vertex(v) for v in g


def plotGraph(g, layout="circle"):
    """ Plots the graph g, with layout type layout """
    gw = GraphWorld()
    
    if layout == "random":
        layout = RandomLayout(g)
    elif layout == "force":
        layout = ForceDirectedLayout(g, gw.scale)
    else:
        layout = CircleLayout(g)
        
    
    gw.layout = layout
    gw.show_graph(g, layout)
    import thread
    thread.start_new_thread(gw.mainloop, ())
    #gw.mainloop()
    return gw



def main(script, n=50, graph_type="scalefree", plot_type="circle", *args):
    """ Creates a graph type g with n nodes """
    
    # Dictionary that maps named graphs to their init functions
    graphs = {'complete': CompleteGraph, 'random': RandomGraph,
              'regular': RegularGraph, 'scalefree': ScaleFreeGraph}
              
    # Create and print the graph
    g = graphs[graph_type](n)
    #print g

    # Plot the graph
    plotGraph(g, plot_type)

if __name__ == '__main__':
    import sys
    main(plot_type="force", *sys.argv)
    raw_input()

