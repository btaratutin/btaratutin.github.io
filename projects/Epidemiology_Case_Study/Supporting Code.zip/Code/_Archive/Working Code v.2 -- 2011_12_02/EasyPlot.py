# -*- coding: utf-8 -*-
"""
EasyPlot

Abstracts the python plt module a little bit to make it easy to plot things!


Boris Taratutin
September 19, 2011
"""

import matplotlib.pyplot as plt


class EasyPlot():
    """ A wrapper for making an easy plot func """
    
    _plotscales = {"loglog": plt.loglog, "logx": plt.semilogx, "logy": plt.semilogy, None: plt.plot}
    
    def __init__(self, title="", xlabel="", ylabel="", scale=None, subplots=False, sepfigs=False,
                 titlesize=18, fontsize=15, grid=True, figsize= (8,6), dpi=100, autoexpand=False, legendloc=4,
                showlegend=True):
        """ Initialize graph-wide properties
            If subplots and sepfigs are both false, will plot on the same graph """
        
        # Values our User will probably change often        
        self.title = title
        self.xlabel = xlabel
        self.ylabel = ylabel
        self.scale = scale
        self.subplots = subplots    # Whether we'll draw lines as subplots
        self.sepfigs = sepfigs
        self.legendloc = legendloc
        self.showlegend = showlegend
        
        
        # Values our User probably won't change
        self.titlesize = titlesize
        self.fontsize = fontsize
        self.grid = grid
        self.figsize = figsize
        self.dpi = dpi
        self.autoexpand = autoexpand     
        
        
        
        # Internal Values
        self.graphs = []        # a list of plots/graphs to plot!
        self.colors = self.colorGen()     # call "colors.next()" to get next color
        self.curr_plot = 1  # for generating figures/subplots
        self.plotFunc = self._plotscales[self.scale] # what shall we plot with?
        
    
    def addPlot(self, xs, ys, **kwargs):
        """ Adds plots with (xs, ys, kwargs) (plots=[]) """
        self.graphs.append( (xs, ys, kwargs))
        
        
    
    
    ###------------------ Internal Funcs ---------------------------------------
    
    def colorGen(self):
        """ A color picker generator - will alternate through the various colors
            for drawing to a subplot """
        #colors = matplotlib.colors.cnames.keys()
        colors = ['blue', 'green', 'red', 'cyan', 'magenta', 'indigo', 'black',
                  'pink', 'forestgreen', 'blueviolet']
        num_colors = len(colors)
        c = 0
        while True:
            yield colors[c%num_colors]
            c += 1    
    
    
    
    ###------------------ Execution Level --------------------------------------
        
    def setupGraph(self):
        """ Sets up the visual aspects of the graph (position, labels, etc) """
        plt.title(self.title, fontsize=self.titlesize)
        plt.xlabel(self.xlabel, fontsize=self.fontsize)
        plt.ylabel(self.ylabel, fontsize=self.fontsize)
        plt.grid(self.grid)
        
        
    def setupAxes(self, xmin=None, ymin=None, xmax=None, ymax=None):
        #c_xmin, c_ymin, c_xmax, c_ymax = plt.axis
        print "old axis: ", plt.axis()
        c_xmin, c_xmax = plt.xlim()
        c_ymin, c_ymax = plt.ylim()
        
        # If user passed in values, use them
        if xmin:
            c_xmin = xmin
        if ymin:
            c_ymin = ymin
        
        # Find out what tick step is, and set limits to one above it
        x_step = (plt.xticks()[0][1] - plt.xticks()[0][0])/2
        y_step = (plt.yticks()[0][1] - plt.yticks()[0][0])/2
        
        # Either use user-passed in max values, or expand max. by a tick value
        if xmax:
            c_xmax = xmax
        elif self.autoexpand:
            c_xmax += x_step
        
        if ymax:
            c_ymax = ymax
        elif self.autoexpand:
            c_ymax += y_step
            c_ymin -= y_step
        
        # Set the new values
        plt.xlim(c_xmin, c_xmax)
        plt.ylim(c_ymin, c_ymax)

        
    def plot(self):
        """ Plots the graph(s) set up 
            Each graph is ([xs], [ys], {kwargs}) """
        # color="magenta", marker=">", label="floo", linestyle=" ", linewidth="2.0"
        graphs = self.graphs
        
        fig = plt.figure(self.curr_plot, figsize=self.figsize, dpi=self.dpi)       # Not fully necessary, done automatically
        
        
        for xs, ys, kwargs in graphs:
            
            # Subplots - change color each time
            if self.subplots:
                plt.subplot(len(graphs)*100 + 10 + self.curr_plot)
                fig.subplots_adjust(hspace = 0.5)
                fig.subplots_adjust(left   = 0.15)
                
                kwargs['color'] = kwargs.get('color', self.colors.next())
                
                self.plotFunc(xs, ys, **kwargs)
                self.curr_plot += 1
                
            # Seperate Figures; reinit setup each time
            elif self.sepfigs:
                plt.figure(self.curr_plot)
                
                kwargs['color'] = kwargs.get('color', self.colors.next())                
                self.plotFunc(xs, ys, **kwargs)
                self.setupGraph()
                self.setupAxes()
                
                self.curr_plot += 1
            
            # Same Figures - change colors each time, keep same fig
            else:
                kwargs['color'] = kwargs.get('color', self.colors.next())
                self.plotFunc(xs, ys, **kwargs)
        
        
        # Legend automatically enabled if #graphs > 1
        if len(self.graphs) > 1 and self.showlegend:
            plt.legend(loc=self.legendloc)
            
            
        self.show()
        

    def show(self):
        # Configure the plots using parameters user gave
        self.setupGraph()
        self.setupAxes()
        
        # Draw it for the user
        plt.show()

###------------------ Useful Functions -------------------------------------
def convertListPoints(l):
    """ Converts a list of (x,y) points to a tuple of (xs, ys) """
    xs, ys = zip(*l)
    return(xs, ys)


if __name__ == "__main__":
    pass