# -*- coding: utf-8 -*-
"""
Common methods to all the disease spread modules
"""

from Graph import *

from RegularGraph import RegularGraph
from RandomGraph import RandomGraph
from ScaleFreeGraph import ScaleFreeGraph
from CompleteGraph import CompleteGraph
from SmallWorldGraph import SmallWorldGraph

import random
import dictManip
import copy

def convertModeltoDiseaseModel(g):
    """ converts all the vertices in graph g to fit the Disease spread model.
    
    Gives the vertices the following attributes:
        - state: 
            -- 0 normal:    vertex (person) has not been infected yet.
            -- 1 infected:  vertex (person) has contracted disease and is going through latency period
                            before becoming infectious. Cannot infect other nodes. Cannot be re-infected.
                            lasts for [latent_period]
            -- 2 infectious:vertex (person) has the disease and can infect others.
                            lasts for [infectious_period]
            -- 3 immune:    vertex (person) has finished infectious period and 'recovered'
                            Can no longer be infected, can no longer infect others
        - days_latent: # of days that infected individual has been infected for (use to count to get to 'infectious' state)
        - days_infectious: # of days individual has been infectious. (use to count to get to 'immune' state)
    """
    
    for v in g.vertices():
        v.state = "normal"
        v.days_latent = 0
        v.days_infectious = 0
        


# Dictionary that maps named graphs to their init functions
graphs = {'complete': CompleteGraph, 'random': RandomGraph,
          'regular': RegularGraph, 'scalefree': ScaleFreeGraph,
          'smallworld': SmallWorldGraph}
              

def buildGraph(graph_type, n, **kwargs):
    """ Creates and returns a graph type g with n nodes """
    
    # Create and print the graph (using the global 'graphs' dict. definition)
    g = graphs[graph_type](n, **kwargs)
    return g
    
    
def pickRandomNode(g):
    """ Randomly selects a vertex in g and returns it """
    return random.choice(g.vertices())

def pickRandomMinDegreeNode(g):
    """ Picks a node that has the smallest depth-2 degree (lowest degree + lowest neighbor degree)
        (is relatively far removed from the 'hubs' in the network)"""
    vertex_degrees = {}
    for v in g.vertices():
        # a vertex's depth-2 degree is it's own degree..
        vertex_degrees[v] = len(g.out_edges(v)) 
        
        #..plus that of all of its neighbors
        for neighbor in g.out_vertices(v):
            vertex_degrees[v] += len(g.out_edges(neighbor))
    
    # Turn our dictionary into a sorted list of (vertex, depth-2 degrees)
    sorted_degree_list = dictManip.sortDictGetItems(vertex_degrees, key=1, reverse=False)
    
    # Return the vertex with the minimum degree (the first item is the vertex)
    return sorted_degree_list[0][0]
    

def calcStats(g):
    """ Calculates the stats - # of vertices in each state - for the graph
        returns a dictionary of key: state, val: # verties in that state """
        
    # Generate base dict
    stats = {"normal": 0, "infected": 0, "infectious": 0, "immune":0}

    # increment counts based on state
    for v in g.vertices():
        stats[v.state] += 1
        
    return stats
    
    
def copyGraph(src_graph):
    """copies graph g_new to have the same structure as graph g """
    
    vertices = [copy.copy(v) for v in src_graph.vertices()]
    
    vertices_dict = {}
    for v in vertices:
        vertices_dict[v.label] = v
    
    edges = [Edge(vertices_dict[v1.label], vertices_dict[v2.label]) for v1,v2 in src_graph.edges()]
    
    # Build and convert a graph to our model
    new_graph = Graph(vertices, edges)
    
    return new_graph, vertices_dict