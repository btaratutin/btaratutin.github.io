# -*- coding: utf-8 -*-
"""
Models the spread of disease through a network using the model presented in
Shirley's paper, "The Impacts of Network Topology on Disease Spread"

November, 2011
Boris Taratutin, Abe Kim, Margaret-Ann Seger
"""


from Graph import Graph, Vertex, Edge
from DiseaseSpreadModel import *

import GraphWorld as gw
from EasyPlot import EasyPlot, convertListPoints
import dictManip
import GraphMetrics

import random
import time





def runSimulation(g, n=20, p_infection=0.1, latent_period=3, infectious_period=5, sleep_time=0.1, plot=False):
    """ Initiates and runs the simulation (until every node is infected) 
        The model for the spread of disease is:
        
        1. Randomly select a vertex in the population and designate it as infectious
        2. At each time step, each infectious vertex has probability P of infecting each of its neighbors
        3. Once infected, there's a latency period
        3. After latency, there is infectious period
        4. After infectious, there is non-infectious and immune state
        
        With the following parameters:
            p_infection: probability of a node infecting neighbors if infected
            latent_period: # of days (steps) after node is infected before becomes infectious
            infectious_period: # of days (steps) that node is infectious for
    """
    
    # Infect 1 initial vertex
    #infection_start = pickRandomMinDegreeNode(g)
    infection_start = pickRandomNode(g)
    infection_start.state = "infected"
    
    if plot: plotter = gw.plotGraph(g, layout="force")
    
    # Tracking properties
    network_size = len(g.vertices()) # how mnay vertices there are in the graph (so can know when all have been infected)
    time_step = 0       # num. steps in simulation
    log = {'normal':[], 'infected':[], 'infectious':[], 'immune':[]}            # tuples of (time_step, epidemic_size) throughout the whole
    v_infector_ct = {}   # for a given vertex, how many others has it infected?
    
    
    while True:
        
        # Get the vertices in the graph & randomize (shuffle) their order (so evaluate differently each time)
        vs_in_graph = g.vertices()
        random.shuffle(vs_in_graph)
        
        for v in vs_in_graph:
            # If the vertex is not infected or immune, skip over it
            if v.state == "normal" or v.state == "immune":
                continue
            
            # If vertex is infected, increment latency time, and perform state transition logic.
            elif v.state == "infected":
                v.days_latent += 1
                if v.days_latent >= latent_period:
                    v.days_latent = 0
                    v.state = "infectious"
                    v.color = 'red'
                    #print v, " just became infectious"
            
            # If vertex is infectious, increment infectious time, perform state transition logic,
            # and, if not at immune time yet, implement infection spread model (p infecting neighbors)
            elif v.state == "infectious":
                v.days_infectious += 1
                if v.days_infectious >= infectious_period:
                    v.days_infectious = 0
                    v.state = "immune"
                    v.color = 'black'
                    #print v, " just became immune"
                
                # figure out if vertex infected any of its neighbors or not
                else:
                    for neighbor in g.out_vertices(v):
                        # neighbor can only get infected if his state is non-infected (normal)
                        # and if probability of infection is achieved
                        if neighbor.state == "normal" and random.random() <= p_infection:
                            neighbor.state = "infected"
                            neighbor.color = 'yellow'
                            #print v, " just infected ", neighbor
                            v_infector_ct[v] = v_infector_ct.get(v, 0) + 1
         
        
        # Calculate graph statistics (how many nodes in each state)
        stats = calcStats(g)
        
        # Logging function - tracks infection progress
        for state,magnitude in stats.iteritems():
            log[state].append((time_step, magnitude) )
            
        # Plotting/visualization of nodes
        if plot:
            gw.updateGraph(plotter, g)
            time.sleep(sleep_time)
            
        # Check if should quit (if there are no infectious/infected nodes - epidemic is finished!)
        if stats['infected'] + stats['infectious'] == 0:
            break
        
        time_step += 1

        
    print "\n\nepidemic simulation done.\n"
    num_infected = stats['immune']
    print num_infected, "/", network_size, " vertices infected, over ", time_step, " time steps"
    return (log, num_infected)
    
    
def compareGraphs(n, p_infection, latent_period, infectious_period, degree, p_node_formation):
    """ Runs a single simulation for a number of graph topologies 
        Shows how epidemic spreads for each individual graph topology - validates our 
        logical assumptions about how the graphs work, and how we would expect
        disease to spread through them
        
        Note: <highly> dependent on p-value and graph-formation values (k-val, p-val for random & small-world)
    """
    
    graphs = {"Random Graph, p=0.1": buildGraph("random", n, p=0.1),
              "Scale Free Graph": buildGraph("scalefree", n),
              "Complete Graph": buildGraph("complete", n),
              "Regular Graph, k=15": buildGraph("regular", n, k=15),
              "Small World Graph, k=3, p=0.7": buildGraph("smallworld", n, k=5, p=0.7) }
    
    plt = EasyPlot("Epidemic Spread Over Different Graph Topologies, n=%s, latent=%s, infectious=%s" %(n, latent_period, infectious_period), 
                   "# days", "epidemic size", legendloc=4, titlesize=14)
    
    #plot = ["Scale Free", "Small World", "Random"]
    plot = graphs.keys()
    for name, graph in graphs.iteritems():
        if name not in plot:
            continue
        convertModeltoDiseaseModel(graph)
        print "\n\nRunning simulation on ", name
        (log, num_infected) = runSimulation(graph, n, p_infection, latent_period, infectious_period, sleep_time, False)
        
        xs, ys = convertListPoints(log['immune'])
        plt.addPlot(xs, ys, label=name)
        
    plt.plot()
    
    
def main_SingleSimulation(graph, n, p_infection, latent_period, infectious_period, sleep_time, plot):
    (log, num_infected) = runSimulation(graph, n, p_infection, latent_period, infectious_period, sleep_time, plot)
    
    """ Runs a simulation that models the spread of disease through a network.
        The infection starts at a random node, and spreads following the epidemic model
        described in Shirley's paper. 
        
        Ultimately, we can plot a visualization of the disease spreading, and a time-plot
        that shows the num. infected people over time
    """

    # Generate Graphs
    plt = EasyPlot("Epidemic Spread (%s/%s infected, p_infection=%s, latent=%s, infectious=%s)" % 
        (num_infected, n, p_infection, latent_period, infectious_period), "# days", "epidemic size", legendloc=6, titlesize=13)
    
    # key = name of state that keeping track of "infectious", etc. 
    # arr = array of (time_step, magnitude) for that state
    to_plot = {'normal': True, 'infected': True, 'infectious': True, 'immune': True}
    for key, arr in log.iteritems():
        if to_plot[key]:
            xs, ys = convertListPoints(arr)
            plt.addPlot(xs, ys, label=key)
    plt.plot()
    
if __name__ == "__main__":
    """ Define the basic parameters to run the simulation with """
    n                   = 100        # num. nodes
    p_infection         = 0.5       # probability of spreading disease
    latent_period       = 2         # num. days between contracting disease and becoming infectious
    infectious_period   = 6         # num. days infectious for
    
    sleep_time          = 0.5     # s to sleep for when plotting
    plot                = False     # plot, or not?
    
    """ Define the graph structure that we will test on """
    #graph = buildGraph("random", n, p=0.5)
    #convertModeltoDiseaseModel(graph)   # Modify this graph's vertices to be "DiseaseModelVertices"
    #main_SingleSimulation(graph, n, p_infection, latent_period, infectious_period, sleep_time, plot)
    
    k                   = 4         # for certain graph types, num. neighbors node is connected to
    p_node_formation    = 0.1       # probability of randomly forming or rewiring a connection
    compareGraphs(n, p_infection, latent_period, infectious_period, k, p_node_formation)
    