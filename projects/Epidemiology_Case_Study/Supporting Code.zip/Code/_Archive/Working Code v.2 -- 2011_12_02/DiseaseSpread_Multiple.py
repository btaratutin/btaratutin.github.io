# -*- coding: utf-8 -*-
"""
Models the spread of disease through a network using the model presented in
Shirley's paper, "The Impacts of Network Topology on Disease Spread"

November, 2011
Boris Taratutin, Abe Kim, Margaret-Ann Seger
"""


from Graph import Graph, Vertex, Edge
from DiseaseSpreadModel import *

import GraphWorld as gw
from EasyPlot import EasyPlot, convertListPoints
import dictManip
import GraphMetrics

import random
import time
import copy


    

def generateGraphstoTest(src_graph, infection_start):
    """ Given the base_graph and infection_start node, will generate a list of other graphs,
        based on removal of a vertex from each one, for us to test """
    graphs_to_test = []
    
    # don't consider the node where the infection is starting from (control var.)
    # TODO: USE OUR ALGORITHM TO PICK THE TOP N VERTICES HERE
    for v in src_graph.vertices():
        if v == infection_start:
            continue
        g, vertices_dict = copyGraph(src_graph)    # Create a new graph with an identical structure
        g.remove_vertex(vertices_dict[v.label])          # modify the new graph to not have this new vertex
        graphs_to_test.append( (g, vertices_dict[v.label]) ) # append the new graph and a reference to the vertex we removed
    
    return graphs_to_test


def runMultipleSimulations(src_graph, n=200, p_infection=0.5, latent_period=3, infectious_period=5):
    """ """
    
    # Infect 1 initial vertex
    infection_start = pickRandomMinDegreeNode(src_graph)
    infection_start.state = "infected"
    
    # Generate the graphs that we will test
    to_test_graphs = generateGraphstoTest(src_graph, infection_start)
    print "graphs going to test: "
    
    master_log = {}
    
    # Start the multiple simulation
    for g, removed_vertex in to_test_graphs:
        print "\ntesting next graph"
        for v in g.vertices():
            if v.state == "infected":
                print "infected node  is ", v
                break
        
        # Tracking properties
        network_size = len(g.vertices()) # how many vertices there are in the graph (so can know when all have been infected)
        time_step = 0       # num. steps in simulation
        log = {'normal':[], 'infected':[], 'infectious':[], 'immune':[]}            # tuples of (time_step, epidemic_size) throughout the whole
        v_infector_ct = {}   # for a given vertex, how many others has it infected?
        
        
        while True:
            
            # Get the vertices in the graph & randomize (shuffle) their order (so evaluate differently each time)
            vs_in_graph = g.vertices()
            random.shuffle(vs_in_graph)
            
            for v in vs_in_graph:
                # If the vertex is not infected or immune, skip over it
                if v.state == "normal" or v.state == "immune":
                    continue
                
                # If vertex is infected, increment latency time, and perform state transition logic.
                elif v.state == "infected":
                    v.days_latent += 1
                    if v.days_latent >= latent_period:
                        v.days_latent = 0
                        v.state = "infectious"
                        v.color = 'red'
                        #print v, " just became infectious"
                
                # If vertex is infectious, increment infectious time, perform state transition logic,
                # and, if not at immune time yet, implement infection spread model (p infecting neighbors)
                elif v.state == "infectious":
                    v.days_infectious += 1
                    if v.days_infectious >= infectious_period:
                        v.days_infectious = 0
                        v.state = "immune"
                        v.color = 'black'
                        #print v, " just became immune"
                    
                    # figure out if vertex infected any of its neighbors or not
                    else:
                        for neighbor in g.out_vertices(v):
                            # neighbor can only get infected if his state is non-infected (normal)
                            # and if probability of infection is achieved
                            if neighbor.state == "normal" and random.random() <= p_infection:
                                neighbor.state = "infected"
                                neighbor.color = 'yellow'
                                #print v, " just infected ", neighbor
                                v_infector_ct[v] = v_infector_ct.get(v, 0) + 1
             
            
            # Calculate graph statistics (how many nodes in each state)
            stats = calcStats(g)
            
            # Logging function - tracks infection progress
            for state,magnitude in stats.iteritems():
                log[state].append((time_step, magnitude) )
                
            # Check if should quit (if there are no infectious/infected nodes - epidemic is finished!)
            if stats['infected'] + stats['infectious'] == 0:
                break
            
            time_step += 1
    
        master_log[removed_vertex] = log
            
        print "\n\nepidemic simulation done.\n"
        num_infected = stats['immune']
        print num_infected, "/", network_size, " vertices infected, over ", time_step, " time steps"
        #print log
        #print "\n"
        #print "Node infection mappings:"
        #for pair in dictManip.sortDictGetItems(v_infector_ct)[:20]:
            #print pair, len(g.out_edges(pair[0]))
        
    return master_log
    

    
def main_multiple(graph, n, p_infection, latent_period, infectious_period):
    master_log = runMultipleSimulations(graph, n, p_infection, latent_period, infectious_period)
    
    print "\n\n ALL DONE!"
    #print master_log
    
    plt = EasyPlot("Epidemic Spread over network w./ diff. nodes removed. n:%s, p:%s, latent:%s, infectious:%s" % (n, p_infection, latent_period, infectious_period), 
                   "# days", "epidemic size", titlesize=13, showlegend=False)
    #to_plot = {'normal': False, 'infected': False, 'infectious': False, 'immune': True}
    
    for vertex, plot_data in master_log.iteritems():
        data = plot_data['immune']
        xs, ys = convertListPoints(data)
        plt.addPlot(xs, ys, label=str(vertex.label))
    
    plt.plot()
    
if __name__ == "__main__":
    """ Define the basic parameters to run the simulation with """
    n                   = 500        # num. nodes
    p_infection         = 0.1       # probability of spreading disease
    latent_period       = 5         # num. days between contracting disease and becoming infectious
    infectious_period   = 15         # num. days infectious for
    
    """ Define the graph structure that we will test on """
    graph = buildGraph("scalefree", n)
    convertModeltoDiseaseModel(graph)   # Modify this graph's vertices to be "DiseaseModelVertices"
    
    """ This simulation will generate a bunch of different graphs, by taking the source
        graph and removing each of its vertices one by one, running the simulation,
        and plotting the spread of the epidemic afterwards.
        
        TODO: average these runs N times, because a short run could just be a fluke!
        *DiseaseSpread_Bar is basically the better, mor robust version of this
    """
    
    main_multiple(graph, n, p_infection, latent_period, infectious_period)
    
    
    
    