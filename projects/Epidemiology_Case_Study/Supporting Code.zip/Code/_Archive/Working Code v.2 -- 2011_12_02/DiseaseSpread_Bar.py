# -*- coding: utf-8 -*-
"""
Models the spread of disease through a network using the model presented in
Shirley's paper, "The Impacts of Network Topology on Disease Spread"

November, 2011
Boris Taratutin, Abe Kim, Margaret-Ann Seger
"""


from Graph import Graph, Vertex, Edge

from DiseaseSpreadModel import *

import dijkstra as dj
import GraphWorld as gw
from EasyPlot import EasyPlot, convertListPoints
import dictManip
import GraphMetrics

import random
import time
import copy

import DiseaseSpread_Single


    

def generateGraphstoTest(src_graph, infection_start):
    """ Given the base_graph and infection_start node, will generate a list of other graphs,
        based on removal of a vertex from each one, for us to test """
    graphs_to_test = []
    
    # don't consider the node where the infection is starting from (control var.)
    # TODO: USE OUR ALGORITHM TO PICK THE TOP N VERTICES HERE
    for v in src_graph.vertices():
        if v == infection_start:
            continue
        g, vertices_dict = copyGraph(src_graph)    # Create a new graph with an identical structure
        g.remove_vertex(vertices_dict[v.label])          # modify the new graph to not have this new vertex
        graphs_to_test.append( (g, v) ) # append the new graph and a reference to the vertex we removed
        #vertices_dict[v.label]
    return graphs_to_test


def runMultipleSimulations(src_graph, num_avgs=10, n=200, p_infection=0.5, latent_period=3, infectious_period=5, sleep_time=0.01, plot=False, print_details=False):
    """ """

    # Generate the graphs that we will test
    to_test_graphs = generateGraphstoTest(src_graph, None)
    print "graphs going to test: "
    
    master_log = {}
    
    # Start the multiple simulation
    for g_testing, removed_vertex in to_test_graphs:
        #print "\ntesting next graph"
            
        for n in xrange(num_avgs):
            
            g, vertices_dict = copyGraph(g_testing)
            
            infection_start = pickRandomNode(g)
            infection_start.state = "infected"
            #print "infection started at ", infection_start
        
            # Tracking properties
            network_size = len(g.vertices()) # how many vertices there are in the graph (so can know when all have been infected)
            time_step = 0       # num. steps in simulation
            v_infector_ct = {}   # for a given vertex, how many others has it infected?
            
            
            while True:
                
                # Get the vertices in the graph & randomize (shuffle) their order (so evaluate differently each time)
                vs_in_graph = g.vertices()
                random.shuffle(vs_in_graph)
                
                for v in vs_in_graph:
                    # If the vertex is not infected or immune, skip over it
                    if v.state == "normal" or v.state == "immune":
                        continue
                    
                    # If vertex is infected, increment latency time, and perform state transition logic.
                    elif v.state == "infected":
                        v.days_latent += 1
                        if v.days_latent >= latent_period:
                            v.days_latent = 0
                            v.state = "infectious"
                            v.color = 'red'
                            if print_details: print v, " just became infectious"
                    
                    # If vertex is infectious, increment infectious time, perform state transition logic,
                    # and, if not at immune time yet, implement infection spread model (p infecting neighbors)
                    elif v.state == "infectious":
                        v.days_infectious += 1
                        if v.days_infectious >= infectious_period:
                            v.days_infectious = 0
                            v.state = "immune"
                            v.color = 'black'
                            if print_details: print v, " just became immune"
                        
                        # figure out if vertex infected any of its neighbors or not
                        else:
                            for neighbor in g.out_vertices(v):
                                # neighbor can only get infected if his state is non-infected (normal)
                                # and if probability of infection is achieved
                                if neighbor.state == "normal" and random.random() <= p_infection:
                                    neighbor.state = "infected"
                                    neighbor.color = 'yellow'
                                    if print_details: print v, " just infected ", neighbor
                                    v_infector_ct[v] = v_infector_ct.get(v, 0) + 1
                
                
                # Calculate graph statistics (how many nodes in each state)
                stats = calcStats(g)
                    
                # Check if should quit (if there are no infectious/infected nodes - epidemic is finished!)
                if stats['infected'] + stats['infectious'] == 0:
                    break
                
                time_step += 1
                

            master_log[removed_vertex] = master_log.get(removed_vertex, 0) + stats['immune']
        
        # calc avg of infected nodes
        master_log[removed_vertex] /= float(num_avgs)
            
        avg_num_infected = master_log[removed_vertex]
        print ("%.2f" % avg_num_infected), "/", network_size, " vertices infected for graph with vertex ", removed_vertex, " removed, over ", num_avgs, " runs"
        
    return master_log, src_graph
    


def makeBar(graph, num_avgs, n, p_infection, latent_period, infectious_period, sleep_time, plot):
    
    import matplotlib.pyplot as plt
    import numpy as na
    
    import dsmv2
    
    
    # Calculate baseline number of people infected (average for unmodified graph)
    baseline_num_infected = 0
    
    for i in xrange(num_avgs):
        g, other = copyGraph(graph)
        (log, num_infected) = DiseaseSpread_Single.runSimulation(g, n, p_infection, latent_period, infectious_period, sleep_time, False)
        baseline_num_infected += num_infected
    baseline_num_infected /= num_avgs
    
    master_log, src_graph = runMultipleSimulations(graph, num_avgs, n, p_infection, latent_period, infectious_period, sleep_time, plot)
    vertices, vals = dictManip.sortDict(master_log, reverse=False)
    
    
    print "\n\nSimulation Done Running. Top Values are:"
    i = 0
    for vertex, val in zip(vertices, vals):
        # Highlight the vertices we want to plot
        if i == 0:
            vertex.color = "red"
        elif i > 0 and i <= 2:
            vertex.color = "yellow"
        print vertex, ", Num. Fewer Nodes infected:", (baseline_num_infected-val), ", degree: ", len(src_graph.out_edges(vertex))
        i += 1
    
    
    print "num. baseline nodes infected: ", baseline_num_infected
    
    #numerical_results = dj.mostFrequent(src_graph)
    numerical_results = dsmv2.main(src_graph, N=10)
    
    print "\nNumerically, the top nodes to be removed are:"
    for val, vertices in numerical_results:
        print ("%.3f" % val), " - ", vertices
        
    # ------------ Results -------------- #
    
    print "\n\n\n"
    print "RESULTS!"
    
    print "Our Numerical Analysis predicted the following nodes to be the most important for robustness are: "
    for val, vertices in numerical_results[:2]:
        print ("%.3f" % val), " - ", vertices
    
    print "\nOur model tells us that removing of these vertices will produce the following reductions in epidemic size: "
    max_percent_ppl_saved = 0
    for val, vertices in numerical_results[:2]:
        for vertex in vertices:
            num_fewer_infections = baseline_num_infected-master_log[vertex]
            percent_ppl_saved = float(num_fewer_infections)/baseline_num_infected * 100
            print "Removing ", vertex, (" produces %.3f" % num_fewer_infections), (" fewer infections (%.2f%%)" % percent_ppl_saved)
            max_percent_ppl_saved = max(max_percent_ppl_saved, percent_ppl_saved)
            
    print "\nThe standard epidemic size, without any node removal, is: ", baseline_num_infected
    max_num_saved = baseline_num_infected-min(master_log.values())
    max_percent_max_num_saved =  max_num_saved/baseline_num_infected * 100
    print "The maximum number of fewer infections we could have is: %.3f (%.2f%%)" % (max_num_saved, max_percent_max_num_saved)
    print "That means, for these parameters, our algorithm efficiency is %.2f%%" % (max_percent_ppl_saved/max_percent_max_num_saved * 100)
    # ------------ End Results -------------- #
    
    
    # Plotting
    if plot: 
        plotter = gw.plotGraph(src_graph, layout="force")
        #gw.updateGraph(plotter, src_graph)
    
    xlocations = na.array(range(len(vals)))+0.5
    width = 0.5
    plt.bar(xlocations, vals,width=width)
    plt.yticks(range(0, 8))
    plt.xticks(xlocations+ width/2, vertices)
    plt.xlim(0, xlocations[-1]+width*2)
    plt.title("Epidemic Spread over network w./ diff. nodes removed. n:%s, p:%s, latent:%s, infectious:%s, num. avgs:%s" % (n, p_infection, latent_period, infectious_period, num_avgs))
    plt.gca().get_xaxis().tick_bottom()
    plt.gca().get_yaxis().tick_left()
    plt.show()
    

    
if __name__ == "__main__":
    """ Define the basic parameters to run the simulation with """
    num_avgs            = 30        # num times to run simulation and average to account for randomness
    n                   = 50        # num. nodes to generate in he graph
    p_infection         = 0.1      # probability of spreading disease
    latent_period       = 5         # num. days between contracting disease and becoming infectious
    infectious_period   = 10         # num. days infectious for
    sleep_time          = 0.05     # s to sleep for when plotting
    plot                = True     # plot, or not?
    
    """ Define the graph structure that we will test on """
    graph = buildGraph("scalefree", n)
    convertModeltoDiseaseModel(graph)   # Modify this graph's vertices to be "DiseaseModelVertices"
    
    """ This file will generate a histogram of [node removed] vs. [Epidemic size].
        To account for the randomness in simulation, we will run each epidemic N times (num_avgs),
        and start the disease spread at a different node (random) each time. The higher num_avgs is, the higher the 
        simulation accuracy will be 
        
        Ultimately, the simulation will show us which nodes are the most important to remove. Besides the simulation graph,
        running makeBar will output a list of (vertex, epidemic size, degree) that shows us how big the average epidemic got to
        when we removed vertex V. It's degree is listed for our reference.
        
        We also, in this code, call the analytic method that we developed that tries to calculate, analytically,
        which nodes are the most important to remove in the network.
    """
    makeBar(graph, num_avgs, n, p_infection, latent_period, infectious_period, sleep_time, plot)
    
    
    
    
