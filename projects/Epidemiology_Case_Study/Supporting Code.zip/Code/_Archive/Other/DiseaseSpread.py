# -*- coding: utf-8 -*-
"""
Models the spread of disease through a network using the model presented in
Shirley's paper, "The Impacts of Network Topology on Disease Spread"

November, 2011
Boris Taratutin, Abe Kim, Margaret-Ann Seger
"""


from Graph import Graph, Vertex, Edge
from RegularGraph import RegularGraph
from RandomGraph import RandomGraph
from ScaleFreeGraph import ScaleFreeGraph
from CompleteGraph import CompleteGraph

import GraphWorld as gw
from EasyPlot import EasyPlot, convertListPoints
import dictManip
import GraphMetrics

import random
import time



def convertModeltoDiseaseModel(g):
    """ converts all the vertices in graph g to fit the Disease spread model.
    
    Gives the vertices the following attributes:
        - state: 
            -- 0 normal:    vertex (person) has not been infected yet.
            -- 1 infected:  vertex (person) has contracted disease and is going through latency period
                            before becoming infectious. Cannot infect other nodes. Cannot be re-infected.
                            lasts for [latent_period]
            -- 2 infectious:vertex (person) has the disease and can infect others.
                            lasts for [infectious_period]
            -- 3 immune:    vertex (person) has finished infectious period and 'recovered'
                            Can no longer be infected, can no longer infect others
        - days_latent: # of days that infected individual has been infected for (use to count to get to 'infectious' state)
        - days_infectious: # of days individual has been infectious. (use to count to get to 'immune' state)
    """
    
    for v in g.vertices():
        v.state = "normal"
        v.days_latent = 0
        v.days_infectious = 0
        


# Dictionary that maps named graphs to their init functions
graphs = {'complete': CompleteGraph, 'random': RandomGraph,
          'regular': RegularGraph, 'scalefree': ScaleFreeGraph}
              

def buildGraph(graph_type="scalefree", n=10):
    """ Creates and returns a graph type g with n nodes """
    
    # Create and print the graph (using the global 'graphs' dict. definition)
    g = graphs[graph_type](n)
    
    return g
    
    
def startInfection(g):
    """ Randomly selects a vertex in g and marks it as infectious """
    vs = g.vertices()
    infection_start_v = random.choice(vs)
    infection_start_v.state = "infected"
    
    print infection_start_v, " is the first infected node"
    

def calcStats(g):
    """ Calculates the stats - # of vertices in each state - for the graph
        returns a dictionary of key: state, val: # verties in that state """
        
    # Generate base dict
    stats = {"normal": 0, "infected": 0, "infectious": 0, "immune":0}

    # increment counts based on state
    for v in g.vertices():
        stats[v.state] += 1
        
    return stats


def runSimulation(n=20, p_infection=0.1, latent_period=3, infectious_period=5, sleep_time=0.1, plot=False):
    """ Initiates and runs the simulation (until every node is infected) 
        The model for the spread of disease is:
        
        1. Randomly select a vertex in the population and designate it as infectious
        2. At each time step, each infectious vertex has probability P of infecting each of its neighbors
        3. Once infected, there's a latency period
        3. After latency, there is infectious period
        4. After infectious, there is non-infectious and immune state
        
        With the following parameters:
            p_infection: probability of a node infecting neighbors if infected
            latent_period: # of days (steps) after node is infected before becomes infectious
            infectious_period: # of days (steps) that node is infectious for
    """
        
    # Create the graph, and upgrade its vertices to be "DiseaseModelVertices"
    g = buildGraph("scalefree", n)
    convertModeltoDiseaseModel(g)
    
    # Infect 1 initial vertex
    startInfection(g)
    if plot: plotter = gw.plotGraph(g, layout="force")
    
    # Tracking properties
    network_size = len(g.vertices()) # how mnay vertices there are in the graph (so can know when all have been infected)
    time_step = 0       # num. steps in simulation
    log = {'normal':[], 'infected':[], 'infectious':[], 'immune':[]}            # tuples of (time_step, epidemic_size) throughout the whole
    v_infector_ct = {}   # for a given vertex, how many others has it infected?
    
    
    while True:
        
        # Get the vertices in the graph & randomize (shuffle) their order (so evaluate differently each time)
        vs_in_graph = g.vertices()
        random.shuffle(vs_in_graph)
        
        for v in vs_in_graph:
            # If the vertex is not infected or immune, skip over it
            if v.state == "normal" or v.state == "immune":
                continue
            
            # If vertex is infected, increment latency time, and perform state transition logic.
            elif v.state == "infected":
                v.days_latent += 1
                if v.days_latent >= latent_period:
                    v.days_latent = 0
                    v.state = "infectious"
                    v.color = 'red'
                    print v, " just became infectious"
            
            # If vertex is infectious, increment infectious time, perform state transition logic,
            # and, if not at immune time yet, implement infection spread model (p infecting neighbors)
            elif v.state == "infectious":
                v.days_infectious += 1
                if v.days_infectious >= infectious_period:
                    v.days_infectious = 0
                    v.state = "immune"
                    v.color = 'black'
                    print v, " just became immune"
                
                # figure out if vertex infected any of its neighbors or not
                else:
                    for neighbor in g.out_vertices(v):
                        # neighbor can only get infected if his state is non-infected (normal)
                        # and if probability of infection is achieved
                        if neighbor.state == "normal" and random.random() <= p_infection:
                            neighbor.state = "infected"
                            neighbor.color = 'yellow'
                            print v, " just infected ", neighbor
                            v_infector_ct[v] = v_infector_ct.get(v, 0) + 1
         
        
        # Calculate graph statistics (how many nodes in each state)
        stats = calcStats(g)
        
        # Logging function - tracks infection progress
        for state,magnitude in stats.iteritems():
            log[state].append((time_step, magnitude) )
            
        # Plotting/visualization of nodes
        if plot:
            gw.updateGraph(plotter, g)
            time.sleep(sleep_time)
            
        # Check if should quit (if there are no infectious/infected nodes - epidemic is finished!)
        if stats['infected'] + stats['infectious'] == 0:
            break
        
        time_step += 1

        
    print "\n\nepidemic simulation done.\n"
    num_infected = stats['immune']
    print num_infected, "/", network_size, " vertices infected, over ", time_step, " time steps"
    print log
    print "\n"
    print "Node infection mappings:"
    for pair in dictManip.sortDictGetItems(v_infector_ct)[:20]:
        print pair, len(g.out_edges(pair[0]))
    return (log, num_infected)
    
if __name__ == "__main__":
    n                   = 50        # num. nodes
    p_infection         = 0.5       # probability of spreading disease
    latent_period       = 2         # num. days between contracting disease and becoming infectious
    infectious_period   = 6         # num. days infectious for
    sleep_time          = 0.05     # s to sleep for when plotting
    plot                = True     # plot, or not?
    
    (log, num_infected) = runSimulation(n, p_infection, latent_period, infectious_period, sleep_time, plot)

    # Generate Graphs
    plt = EasyPlot("Epidemic Spread (%s/%s infected, p_infection=%s, latent=%s, infectious=%s)" % 
        (num_infected, n, p_infection, latent_period, infectious_period), "# days", "epidemic size", legendloc=6, titlesize=13)
    
    # key = name of state that keeping track of "infectious", etc. 
    # arr = array of (time_step, magnitude) for that state
    to_plot = {'normal': True, 'infected': True, 'infectious': True, 'immune': True}
    for key, arr in log.iteritems():
        if to_plot[key]:
            xs, ys = convertListPoints(arr)
            plt.addPlot(xs, ys, label=key)
    plt.plot()
    