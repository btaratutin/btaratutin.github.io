# -*- coding: utf-8 -*-
"""
Stuff removed from randomgraph
that doesnt fall within the class definition
"""

def show_graph(g):
    import GraphWorld

    #~ for v in g.vertices():
        #~ if v.visited: 
            #~ v.color = 'white'
        #~ else:
            #~ v.color = 'red'

    layout = GraphWorld.CircleLayout(g)
    gw = GraphWorld.GraphWorld()
    gw.show_graph(g, layout)
    gw.mainloop()


def create_random_graph(n, p):
    """Generates a random graph with (n) vertices and probability (p).
    Returns True if connected, False otherwise.
    """
    labels = string.lowercase + string.uppercase + string.punctuation
    vs = [Vertex(c) for c in labels[:n]]
    g = RandomGraph(vs)
    g.add_random_edges(p=p)
    show_graph(g)
    return g


def test_p(n, p, num):
    """Generates (num) random graphs with (n) vertices and
    probability (p) and return the count of how many are connected.
    """
    count = 0
    for i in range(num):
        if test_graph(n, p):
            count += 1
    return count