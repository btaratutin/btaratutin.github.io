# -*- coding: utf-8 -*-
"""
methods not used in DiseaseSpread.py
"""

class DiseaseModelVertex(Vertex):
    """ A vertex that can be used in the disease model. Has the following attributes:
        - state: 
            -- 0 normal:    vertex (person) has not been infected yet.
            -- 1 infected:  vertex (person) has contracted disease and is going through latency period
                            before becoming infectious. Cannot infect other nodes. Cannot be re-infected.
                            lasts for [latent_period]
            -- 2 infectious:vertex (person) has the disease and can infect others.
                            lasts for [infectious_period]
            -- 3 immune:    vertex (person) has finished infectious period and 'recovered'
                            Can no longer be infected, can no longer infect others
        - days_latent: # of days that infected individual has been infected for (use to count to get to 'infectious' state)
        - days_infectious: # of days individual has been infectious. (use to count to get to 'immune' state)
    """
    
    def __new__(self, state, days_latent=0, days_infectious=0):
        self.state = "normal"
        self.days_latent = 0
        self.days_infectious = 0