# -*- coding: utf-8 -*-
"""

Contains all of the methods for setting up and simulating the spread of disease in a network

"""
# Add subfolders
import sys
sys.path = ["Graph Structures", "Tools"] + sys.path


# Python Modules
import random


# Our Modules/Tools
import graphTools
import dictManip
from EasyPlot import EasyPlot, convertListPoints
import DiseaseSpread_Analytical

# Our Objects
from Graph import *
import GraphWorld as gw

from RegularGraph import RegularGraph
from RandomGraph import RandomGraph
from ScaleFreeGraph import ScaleFreeGraph
from CompleteGraph import CompleteGraph
from SmallWorldGraph import SmallWorldGraph

from DiseaseSpreadModel import DiseaseSpreadModel, diseaseModelGraphCopy




### --------------- Simulation Tools & Shortcuts ---------------------###

def pickRandomNode(g):
    """ Randomly selects a vertex in g and returns it """
    return random.choice(g.vertices())


def pickRandomMinDegreeNode(g):
    """ Picks a node that has the smallest depth-2 degree (lowest degree + lowest neighbor degree)
        (is relatively far removed from the 'hubs' in the network)"""
    vertex_degrees = {}
    for v in g.vertices():
        # a vertex's depth-2 degree is it's own degree..
        vertex_degrees[v] = len(g.out_edges(v)) 
        
        #..plus that of all of its neighbors
        for neighbor in g.out_vertices(v):
            vertex_degrees[v] += len(g.out_edges(neighbor))
    
    # Turn our dictionary into a sorted list of (vertex, depth-2 degrees)
    sorted_degree_list = dictManip.sortDictGetItems(vertex_degrees, key=1, reverse=False)
    
    # Return the vertex with the minimum degree (the first item is the vertex)
    return sorted_degree_list[0][0]

def calcStats(g):
    """ Calculates the stats - # of vertices in each state - for the graph
        returns a dictionary of key: state, val: # verties in that state
        
        Useful for analyzing the 'state' of the graph (how many nodes infected,
                                                        infectious, etc. """
        
    # Generate base dict of stats
    stats = {"normal": 0, "infected": 0, "infectious": 0, "immune":0}

    # Increment counts based on state
    for v in g.vertices():
        stats[v.state] += 1
        
    return stats


def calcEpidemicSize(simulation_log):
    """ Given a simulation log, will calculate the size of the epidemic """
    # Index by [State Type] > [Last value in the log] > [time_step, or magnitude]
    return simulation_log['immune'][-1][1]

### --------------- The Simulation ---------------------###

def Single_Simulation(g, p_infection=0.5, latent_period=3, infectious_period=5):
    """ Runs 1 simulation of the disease spreading through a network 

        Returns (simulation_log, num_infected)
        
        "simulation_log" is a dictionary containing stats on nodes (for plotting)
            {'normal':[], 'infected':[], 'infectious':[], 'immune':[]}
            - Each list [] within this dictionary contains a tuple of
              (timestep, value)(simulation_log, epidemic_size) - so that you can plot the progression
              
        "epidemic_size" is the number of nodes made 'immune' (killed) by the time the epidemic stops
    """
    ###----- Initializations -----###
    
    """ ALWAYS Create a copy of the graph before running a test on it. Never a case when don't want to do this 
        Also, makes sure that it's a "disease model" type of graph, by converting it accordingly """
    g = diseaseModelGraphCopy(g)
    
    # Initialize simulation log
    # Contains stats about the progression of disease spread for each node state
        # Each node state contains an array of tuples (time_step, epidemic_size)
        # So that we can track the progression of disease spread over time
    simulation_log = {'normal':[], 'infected':[], 'infectious':[], 'immune':[]}
    
    # Initialize Simulation Parameters
    time_step = 0       # How long epidemic has been developing


    # Begin the infection at a random vertex
    pickRandomNode(g).state = "infected"
    #pickRandomMinDegreeNode(g).state = "infected"


    ###----- Run the Simulation -----###
    # Runs the simulation
    # First, figure out which nodes should change state
    # Then, go through and modify the states of the affected nodes
        # (necessary to do for simulation logic purposes - so don't propagate 
        #  disease thru mult. nodes in 1 iteration)
    # Lastly, calculate statistics and perform administrative tasks
    while True:
        
        # Used to keep track of node state transitions resulting from simulation logic
        state_transitions = []
        
        # Iterate through every node (vertex) in the graph
        for v in g.vertices():
            # If the vertex is not infected or immune, skip over it
            if v.state == "normal" or v.state == "immune":
                continue
            
            # If vertex is infected, increment latency time, and perform state transition logic.
            elif v.state == "infected":
                v.days_latent += 1
                
                if v.days_latent >= latent_period:
                    state_transitions.append( (v, "infectious") )
                    
            # If vertex is infectious, increment infectious time, perform state transition logic,
            # and, if not at immune time yet, implement infection spread model (p infecting neighbors)
            elif v.state == "infectious":
                v.days_infectious += 1
                
                # If a vertex is at the end of its infectious_period, it becomes immune (dies)
                if v.days_infectious >= infectious_period:
                    state_transitions.append( (v, "immune") )
                    
                # If a vertex is not yet at the end of its infectious period,
                    # it has a probability p_infection of infecting all of its neighbors
                    # (but only if they themselves have never been infected)
                else:
                    for neighbor in g.out_vertices(v):
                        if neighbor.state == "normal" and random.random() <= p_infection:
                            state_transitions.append( (neighbor, "infected") )
                   
                    
                    
        # Go through and apply the state transitions, modifying and resetting node states
        for v, transition in state_transitions:
            if transition == "infectious":
                v.days_latent = 0
                v.state = "infectious"
                
            elif transition == "immune":
                v.days_infectious = 0
                v.state = "immune"
                
            elif transition == "infected":
                v.state = "infected"


            
        # Calculate graph statistics and perform administrative tasks
        # "Stats" is stored as a dictionary, keyed by node state, whose items are the # of nodes in that state
        stats = calcStats(g)
        
        # Logging function - tracks infection progress
        for state, magnitude in stats.iteritems():
            simulation_log[state].append((time_step, magnitude) )
            
        # Check if should quit (if there are no infectious/infected nodes - epidemic is finished!)
        if stats['infected'] + stats['infectious'] == 0:
            break
        
        time_step += 1

    
    if level1_print: print "\nEpidemic Simulation Finished."
    if level1_print: print calcEpidemicSize(simulation_log), "/", len(g.vertices()), " vertices infected, over ", time_step, " time steps"
    return simulation_log
    
        

### --------------- Intermediate Simulations ---------------------###

def Averaged_Simulation(g, p_infection, latent_period, infectious_period, num_avgs):
    """ Runs a simulation of a disease spreading through a network N times 
    
        Returns (avg_num_infected), the average size of the epidemic over the course
            of N runs 
    """
    avg_epidemic_size = 0
    
    for i in xrange(num_avgs):
        simulation_log = Single_Simulation(g, p_infection, latent_period, infectious_period)
        avg_epidemic_size += calcEpidemicSize(simulation_log)
    
    avg_epidemic_size /= num_avgs
    if level2_print: print "\nThe average epidemic size over ", num_avgs, " runs is ", avg_epidemic_size    
    
    return avg_epidemic_size


def Multiple_Simulations(graphs, p_infection, latent_period, infectious_period):
    """ Runs the simulation on a number of different graph topologies 
        Note: Each graph must have a unique name for this to work!
    
        Returns a "master log" of all the individual graph's logs, keyed by graph name"""
    master_log = {}
    
    for g in graphs:
        simulation_log = Single_Simulation(g, p_infection, latent_period, infectious_period)
        master_log[g.name] = simulation_log
        
    return master_log


def Multiple_Averaged_Simulations(graphs, p_infection, latent_period, infectious_period, num_avgs):
    """ Runs an averaged simulation on a number of different graph topologies
        Note: Each graph must have a unique name for this to work!
    
        Returns a dictionary of avg. epidemic sizes, indexed by graph name"""
        
    print "\nStarting to run Multiple Averaged Simulations"
    avg_epidemic_sizes = {}
    
    for g in graphs:
        avg_epidemic_size = Averaged_Simulation(g, p_infection, latent_period, infectious_period, num_avgs)
        avg_epidemic_sizes[g.name] = avg_epidemic_size
        
    print "\nMultiple Averaged Simulations Finished Running."
        
    return avg_epidemic_sizes
      
      
      
### --------------- The Functions we call to give us different outputs ---------------------###

def Plot_Single_Simulation(base_graph, p_infection, latent_period, infectious_period):
    simulation_log = Single_Simulation(base_graph, p_infection, latent_period, infectious_period)

    plt = EasyPlot("Epidemic Spread (n:%s, p:%s, latent:%s, infectious:%s)" % (n, p_infection, latent_period, infectious_period), 
                   "# Days", "# People in State", titlesize=12, legendloc=6, marker=" ")    
    
    linestyle = {'normal':'--', 'infected':'-', 'infectious':'-', 'immune' : '-'}
    marker = {'normal':'', 'infected':'^', 'infectious':'+', 'immune' : '-'}
    for state, data in simulation_log.iteritems():
        print state
        xs, ys = convertListPoints(data)
        plt.addPlot(xs, ys, label=state, linestyle=linestyle[state], marker=marker[state])
        
    plt.plot()
  
def Infection_Size_Variability(base_graph, p_infection, latent_period, infectious_period, num_runs, to_plot=True):
    """ Runs an epidemic simulation num_runs time
    
        Plots and prints a histogram of "infection size" vs. "frequency" - so we
        can see what the distribution of epidemic sizes is (how much randomness affects it)
    """
    histogram = {}          # Plot the histogram
    # Initialize histogram    
    for i in xrange(n+1):
        histogram[i] = 0
        
    simulation_logs = []    # Plot the progressions
    
    for i in xrange(num_avgs):
        simulation_log = Single_Simulation(base_graph, p_infection, latent_period, infectious_period)
        simulation_logs.append(simulation_log)
        epidemic_size = calcEpidemicSize(simulation_log)
        histogram[epidemic_size] = histogram.get(epidemic_size, 0) + 1 # add to histogram
        
    # Plot histogram
    import matplotlib.pyplot as plt
    xs, ys = convertListPoints(dictManip.sortDictGetItems(histogram, key=0, reverse=False))
    plt.bar(xs, ys)
    plt.title("Epidemic size histogram. n:%s, p:%s, latent:%s, infectious:%s, num_runs:%s" % (n, p_infection, latent_period, infectious_period, num_runs))
    plt.xlabel("Epidemic Size")
    plt.ylabel("Frequency")
    plt.show()
    
    
    # Plot the progression
    if not to_plot:
        return
    plt = EasyPlot("Epidemic Spread over same network, mult times. n:%s, p:%s, latent:%s, infectious:%s, num_avgs:%s" % (n, p_infection, latent_period, infectious_period, num_avgs), 
                   "Time", "Epidemic Size", titlesize=12)    
    
    for log in simulation_logs:
        data = log['immune']
        xs, ys = convertListPoints(data)
        plt.addPlot(xs, ys)
        
    plt.plot()


def Node_Removal_Simulation(base_graph, p_infection, latent_period, infectious_period):
    """ Generates a number of graphs by removing individual nodes from them
        runs an avgeraged simulation on each one, and returns the avg. epidemic size.
        
        Plots epidemic grown (# immune nodes) over time for each simulation run
    """
    
    # Generate Test graphs + run simulations on them
    graphs_to_test = graphTools.generateTestSuiteGraphs(base_graph)
    
    epidemic_growth_logs = Multiple_Simulations(graphs_to_test, p_infection, latent_period, infectious_period)
    
    
    # Visualize the results
    plt = EasyPlot("Epidemic Spread over diff networks. n:%s, p:%s, latent:%s, infectious:%s, num_avgs:%s" % (n, p_infection, latent_period, infectious_period, num_avgs), 
                   "Time", "Epidemic Size", titlesize=13, showlegend=False)    
    
    for (node_removed, log) in epidemic_growth_logs.iteritems():
        data = log['immune']
        xs, ys = convertListPoints(data)
        plt.addPlot(xs, ys, label=str(node_removed.label))
        
    plt.plot()
        




def Node_Removal_Averaged_Simulation(base_graph, p_infection, latent_period, infectious_period, num_avgs, calc_analytical=False, plotit=False):
    """ Generates a number of graphs by removing individual nodes from them
        runs an avgeraged simulation on each one, and returns the avg. epidemic size.
        
        Plots avg. epidemic size vs. node # 
        prints a list of length N nodes of the smallest epidemic sizes
        
        returns the node that gave us the smallest epidemic size
        """
    n = len(base_graph.vertices())
        
    # Generate Test graphs + run simulations on them
    graphs_to_test = graphTools.generateTestSuiteGraphs(base_graph)
    
    avg_epidemic_sizes = Multiple_Averaged_Simulations(graphs_to_test, p_infection, latent_period, infectious_period, num_avgs)
    base_epidemic_size = Averaged_Simulation(base_graph, p_infection, latent_period, infectious_period, num_avgs)
    
    # Subtract the base epidemic size from each new graph test, so we only care about the <difference>, not the absolute size
    for key in avg_epidemic_sizes.keys():
        avg_epidemic_sizes[key] -= base_epidemic_size
    
    top_nodes = dictManip.sortDictGetItems(avg_epidemic_sizes, key=1, reverse=False)  
    
    # Print Analytical Results    
    if level2_print: print "\n\nEffect of Node removal on epidemic size: "
    for (vertex_removed, epidemic_size) in top_nodes:
        if level2_print: print vertex_removed, ": ", epidemic_size
    
    if level2_print: print "\nAvg. (Baseline) Epidemic size: ", base_epidemic_size
    if level2_print: print "Smallest Epidemic Possible:"
    most_important_node = top_nodes[0][0]
    num_fewer_infected = abs(top_nodes[0][1])
    percent_fewer_infected = num_fewer_infected/float(base_epidemic_size) * 100
    if level2_print: print "Removing ", most_important_node, " produces ", num_fewer_infected, " fewer infections (%s/%s) (%.1f%%)"  % (base_epidemic_size-num_fewer_infected, base_epidemic_size, percent_fewer_infected)
    
    if calc_analytical:
        # Compare to Analytical Heuristic Results
        analytical_results = DiseaseSpread_Analytical.main(base_graph, 3)
        print "\nAnalytical Results say the following are the most important nodes:"
        for (val, node) in analytical_results:
            node = node[0] # "node" is really a list of nodes - so just get first elem
            print node, ": ", val, " (%.1f%% guess efficiency) - %s fewer infected" % (abs(avg_epidemic_sizes[node])/float(num_fewer_infected) * 100, abs(avg_epidemic_sizes[node]))
        

    if plotit:
        # Visualize the results
        plt = EasyPlot("Epidemic Spread over network w./ diff. nodes removed. n:%s, p:%s, latent:%s, infectious:%s, num_avgs:%s" % (n, p_infection, latent_period, infectious_period, num_avgs), 
                       "Vertex # Removed", "Epidemic Size", titlesize=15, autoexpand=True, marker=".")
                       
        verticalLinePlot(plt, dictManip.sortDictGetItems(avg_epidemic_sizes, key=0, reverse=False))
        
        # mark the most important node and plot graph
        base_graph.get_vertex(most_important_node).color = 'yellow'
        gw.plotGraph(base_graph, layout="force")
        plt.plot()
    
    return top_nodes
    

def verticalLinePlot(plt, xy_pairs, **kwargs):
    
    x_val = 0
    for (x, y) in xy_pairs: # sort by name
        plt.simplePlot([x_val, x_val], [0, y], linewidth=1.5, color='blue', marker='-')   # vertical line
        plt.simplePlot(x_val, y, color='blue', marker='*')                               # End of line marker
        x_val+=1
        
    # Draw horizontal baseline
    plt.simplePlot(range(x_val), [0]*x_val, linewidth=1.5, color='green', marker='-')
    


level1_print = False
level2_print = True

if __name__ == "__main__":
    
    # Constants
    graphs = {'complete': CompleteGraph, 'random': RandomGraph,
          'regular': RegularGraph, 'scalefree': ScaleFreeGraph,
          'smallworld': SmallWorldGraph}
    
    # Graph Parameters
    graph_type = "scalefree"    # Graph topology to generate
    n = 500                    # Number of nodes within graph
    kwargs = {}
    base_graph = graphs[graph_type](n, **kwargs)
    
    # Simulation Parameters
    p_infection = 0.5
    latent_period = 3
    infectious_period = 6
    num_avgs = 50
    show_graph = True
    calc_analytical = False      # Run analytical calculation? (Warning: [VERY] SLOW for node N's > 100)
    to_plot = True
    
    # What do you want to run?
    
    print Plot_Single_Simulation(base_graph, p_infection, latent_period, infectious_period)
    #print Averaged_Simulation(base_graph,p_infection, latent_period, infectious_period, num_avgs)
    #Node_Removal_Averaged_Simulation(base_graph,p_infection, latent_period, infectious_period, num_avgs, calc_analytical)
    #Node_Removal_Simulation(base_graph, p_infection, latent_period, infectious_period)
    #Infection_Size_Variability(base_graph, p_infection, latent_period, infectious_period, num_avgs, to_plot)
