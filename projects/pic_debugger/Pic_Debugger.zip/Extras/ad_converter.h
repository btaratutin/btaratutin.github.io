#ifndef h_ad_converter
#define h_ad_converter

	unsigned char ADConversion(unsigned char);

#endif